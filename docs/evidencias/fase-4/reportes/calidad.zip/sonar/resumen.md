### Puerta de calidad, Tabla 51: OK

| Indicador | Umbral | Medido |
|---|---|---|
| Cobertura en codigo nuevo | >= 80 % | sin dato |
| Errores bloqueantes | 0 | 0 |
| Errores criticos | 0 | 0 |
| Duplicidad en codigo nuevo | < 3 % | sin dato |
| Calificacion de seguridad (1 = A, 2 = B) | <= 2 | 1.0 |
| Deuda tecnica, en minutos (no rechaza: se documenta y se agenda) | < 480 | 0 |

Lineas nuevas: 0. Commit evaluado: 3f72aca77adfc5b8462c62f6126609a96ac34402. Base: 29c119ff7105a16054a4e14d2ff7d1d93dae5e4f.
