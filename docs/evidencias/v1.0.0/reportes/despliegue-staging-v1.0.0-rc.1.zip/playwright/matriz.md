### Matriz de compatibilidad (Tabla 50, CO-COM-01)

- Fecha: 2026-11-11T13:24:53Z
- Etiqueta: v1.0.0-rc.1

| Navegador | Resolución | Prioridad | Pruebas | Fallidas | Resultado | Specs con fallas |
|---|---|---|---|---|---|---|
| chrome | 1366x768 | Must | 13 | 0 | Pasa |  |
| chrome | 1920x1080 | Must | 13 | 0 | Pasa |  |
| iphone webkit | 390x844 | Must | 13 | 0 | Pasa |  |
| android chromium | 390x844 | Must | 13 | 0 | Pasa |  |
| zoom200 chromium | 1366x768 | Must | 13 | 0 | Pasa |  |
| firefox | 1366x768 | Should | 12 | 0 | Pasa |  |
| edge | 1366x768 | Should | 12 | 0 | Pasa |  |
