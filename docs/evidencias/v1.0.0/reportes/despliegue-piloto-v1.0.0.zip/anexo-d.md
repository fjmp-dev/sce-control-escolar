### Anexo D, apartado 1: humo en piloto (v1.0.0)

| Verificación | Resultado y evidencia |
|---|---|
| Inicio de sesión por cada rol | no aplica: piloto sin usuarios (piloto-vacio.txt) |
| Inscripción: una confirmada y un rechazo de cada motivo | no aplica: piloto sin usuarios (piloto-vacio.txt) |
| Consulta de horario y calificaciones | no aplica: piloto sin usuarios (piloto-vacio.txt) |
| Pago con doble notificación sin duplicar | no aplica: piloto sin usuarios (piloto-vacio.txt) |
| `/salud` de API y de web responde | Cumple: humo.txt |
| HTTPS con TLS 1.2 o superior | Cumple: tls/tls.json, HTTP a HTTPS y HSTS |
| Sin matrículas reales (18.2, RK-09) | Cumple: sin-datos-reales.txt |
| Accesos revisados (sección 18) | Cumple: accesos.txt |
