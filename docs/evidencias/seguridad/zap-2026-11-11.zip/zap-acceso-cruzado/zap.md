# ZAP Scanning Report

ZAP by [Checkmarx](https://checkmarx.com/).


## Summary of Alerts

| Risk Level | Number of Alerts |
| --- | --- |
| High | 0 |
| Medium | 0 |
| Low | 0 |
| Informational | 2 |




## Insights

| Level | Reason | Site | Description | Statistic |
| --- | --- | --- | --- | --- |
| Medium | Exceeded High | http://localhost:3221 | Percentage of responses with status code 4xx | 100 % |
| Info | Informational | http://localhost:3221 | Percentage of endpoints with content type application/json | 100 % |
| Info | Informational | http://localhost:3221 | Percentage of endpoints with method GET | 61 % |
| Info | Informational | http://localhost:3221 | Percentage of endpoints with method PATCH | 2 % |
| Info | Informational | http://localhost:3221 | Percentage of endpoints with method POST | 23 % |
| Info | Informational | http://localhost:3221 | Percentage of endpoints with method PUT | 12 % |
| Info | Informational | http://localhost:3221 | Count of total endpoints | 73    |







## Alerts

| Name | Risk Level | Number of Instances |
| --- | --- | --- |
| A Client Error response code was returned by the server | Informational | 75 |
| Non-Storable Content | Informational | Systemic |




## Alert Detail



### [ A Client Error response code was returned by the server ](https://www.zaproxy.org/docs/alerts/100000/)



##### Informational (High)

### Description

A response code of 403 was returned by the server.
This may indicate that the application is failing to handle unexpected input correctly.
Raised by the 'Alert on HTTP Response Code Error' script

* URL: http://localhost:3221
  * Node Name: `http://localhost:3221`
  * Method: `GET`
  * Parameter: ``
  * Attack: ``
  * Evidence: `404`
  * Other Info: ``
* URL: http://localhost:3221/
  * Node Name: `http://localhost:3221/`
  * Method: `GET`
  * Parameter: ``
  * Attack: ``
  * Evidence: `404`
  * Other Info: ``
* URL: http://localhost:3221/7828976751894319831
  * Node Name: `http://localhost:3221/7828976751894319831`
  * Method: `GET`
  * Parameter: ``
  * Attack: ``
  * Evidence: `404`
  * Other Info: ``
* URL: http://localhost:3221/alumnos
  * Node Name: `http://localhost:3221/alumnos`
  * Method: `GET`
  * Parameter: ``
  * Attack: ``
  * Evidence: `403`
  * Other Info: ``
* URL: http://localhost:3221/alumnos/
  * Node Name: `http://localhost:3221/alumnos/`
  * Method: `GET`
  * Parameter: ``
  * Attack: ``
  * Evidence: `403`
  * Other Info: ``
* URL: http://localhost:3221/alumnos/2420002
  * Node Name: `http://localhost:3221/alumnos/2420002`
  * Method: `GET`
  * Parameter: ``
  * Attack: ``
  * Evidence: `403`
  * Other Info: ``
* URL: http://localhost:3221/alumnos/2420002/
  * Node Name: `http://localhost:3221/alumnos/2420002/`
  * Method: `GET`
  * Parameter: ``
  * Attack: ``
  * Evidence: `403`
  * Other Info: ``
* URL: http://localhost:3221/alumnos/2420002/3596631309167829206
  * Node Name: `http://localhost:3221/alumnos/2420002/3596631309167829206`
  * Method: `GET`
  * Parameter: ``
  * Attack: ``
  * Evidence: `404`
  * Other Info: ``
* URL: http://localhost:3221/alumnos/2420002/actuator/health
  * Node Name: `http://localhost:3221/alumnos/2420002/actuator/health`
  * Method: `GET`
  * Parameter: ``
  * Attack: ``
  * Evidence: `404`
  * Other Info: ``
* URL: http://localhost:3221/alumnos/2420002/calificaciones
  * Node Name: `http://localhost:3221/alumnos/2420002/calificaciones`
  * Method: `GET`
  * Parameter: ``
  * Attack: ``
  * Evidence: `403`
  * Other Info: ``
* URL: http://localhost:3221/alumnos/2420002/calificaciones/
  * Node Name: `http://localhost:3221/alumnos/2420002/calificaciones/`
  * Method: `GET`
  * Parameter: ``
  * Attack: ``
  * Evidence: `403`
  * Other Info: ``
* URL: http://localhost:3221/alumnos/2420002/cuenta
  * Node Name: `http://localhost:3221/alumnos/2420002/cuenta`
  * Method: `GET`
  * Parameter: ``
  * Attack: ``
  * Evidence: `403`
  * Other Info: ``
* URL: http://localhost:3221/alumnos/2420002/cuenta/
  * Node Name: `http://localhost:3221/alumnos/2420002/cuenta/`
  * Method: `GET`
  * Parameter: ``
  * Attack: ``
  * Evidence: `403`
  * Other Info: ``
* URL: http://localhost:3221/alumnos/2420002/inscripciones
  * Node Name: `http://localhost:3221/alumnos/2420002/inscripciones`
  * Method: `GET`
  * Parameter: ``
  * Attack: ``
  * Evidence: `403`
  * Other Info: ``
* URL: http://localhost:3221/alumnos/2420002/inscripciones/
  * Node Name: `http://localhost:3221/alumnos/2420002/inscripciones/`
  * Method: `GET`
  * Parameter: ``
  * Attack: ``
  * Evidence: `403`
  * Other Info: ``
* URL: http://localhost:3221/alumnos/4060741003737157864
  * Node Name: `http://localhost:3221/alumnos/4060741003737157864`
  * Method: `GET`
  * Parameter: ``
  * Attack: ``
  * Evidence: `403`
  * Other Info: ``
* URL: http://localhost:3221/documentos
  * Node Name: `http://localhost:3221/documentos`
  * Method: `GET`
  * Parameter: ``
  * Attack: ``
  * Evidence: `404`
  * Other Info: ``
* URL: http://localhost:3221/documentos/
  * Node Name: `http://localhost:3221/documentos/`
  * Method: `GET`
  * Parameter: ``
  * Attack: ``
  * Evidence: `404`
  * Other Info: ``
* URL: http://localhost:3221/documentos/9083253599439104370
  * Node Name: `http://localhost:3221/documentos/9083253599439104370`
  * Method: `GET`
  * Parameter: ``
  * Attack: ``
  * Evidence: `403`
  * Other Info: ``
* URL: http://localhost:3221/documentos/DOC-2420002-970E0C14
  * Node Name: `http://localhost:3221/documentos/DOC-2420002-970E0C14`
  * Method: `GET`
  * Parameter: ``
  * Attack: ``
  * Evidence: `403`
  * Other Info: ``
* URL: http://localhost:3221/documentos/DOC-2420002-970E0C14/
  * Node Name: `http://localhost:3221/documentos/DOC-2420002-970E0C14/`
  * Method: `GET`
  * Parameter: ``
  * Attack: ``
  * Evidence: `403`
  * Other Info: ``
* URL: http://localhost:3221/inscripciones
  * Node Name: `http://localhost:3221/inscripciones`
  * Method: `GET`
  * Parameter: ``
  * Attack: ``
  * Evidence: `404`
  * Other Info: ``
* URL: http://localhost:3221/inscripciones/
  * Node Name: `http://localhost:3221/inscripciones/`
  * Method: `GET`
  * Parameter: ``
  * Attack: ``
  * Evidence: `404`
  * Other Info: ``
* URL: http://localhost:3221/inscripciones/1115328814464331054
  * Node Name: `http://localhost:3221/inscripciones/1115328814464331054`
  * Method: `GET`
  * Parameter: ``
  * Attack: ``
  * Evidence: `404`
  * Other Info: ``
* URL: http://localhost:3221/inscripciones/INS-2026B-2420002
  * Node Name: `http://localhost:3221/inscripciones/INS-2026B-2420002`
  * Method: `GET`
  * Parameter: ``
  * Attack: ``
  * Evidence: `404`
  * Other Info: ``
* URL: http://localhost:3221/inscripciones/INS-2026B-2420002/
  * Node Name: `http://localhost:3221/inscripciones/INS-2026B-2420002/`
  * Method: `GET`
  * Parameter: ``
  * Attack: ``
  * Evidence: `404`
  * Other Info: ``
* URL: http://localhost:3221/inscripciones/INS-2026B-2420002/3923102536687624642
  * Node Name: `http://localhost:3221/inscripciones/INS-2026B-2420002/3923102536687624642`
  * Method: `GET`
  * Parameter: ``
  * Attack: ``
  * Evidence: `404`
  * Other Info: ``
* URL: http://localhost:3221/pagos
  * Node Name: `http://localhost:3221/pagos`
  * Method: `GET`
  * Parameter: ``
  * Attack: ``
  * Evidence: `403`
  * Other Info: ``
* URL: http://localhost:3221/pagos/
  * Node Name: `http://localhost:3221/pagos/`
  * Method: `GET`
  * Parameter: ``
  * Attack: ``
  * Evidence: `403`
  * Other Info: ``
* URL: http://localhost:3221/pagos/10
  * Node Name: `http://localhost:3221/pagos/10`
  * Method: `GET`
  * Parameter: ``
  * Attack: ``
  * Evidence: `404`
  * Other Info: ``
* URL: http://localhost:3221/pagos/10/
  * Node Name: `http://localhost:3221/pagos/10/`
  * Method: `GET`
  * Parameter: ``
  * Attack: ``
  * Evidence: `404`
  * Other Info: ``
* URL: http://localhost:3221/pagos/11
  * Node Name: `http://localhost:3221/pagos/11`
  * Method: `GET`
  * Parameter: ``
  * Attack: ``
  * Evidence: `404`
  * Other Info: ``
* URL: http://localhost:3221/pagos/11/
  * Node Name: `http://localhost:3221/pagos/11/`
  * Method: `GET`
  * Parameter: ``
  * Attack: ``
  * Evidence: `404`
  * Other Info: ``
* URL: http://localhost:3221/pagos/11/6224492045812391804
  * Node Name: `http://localhost:3221/pagos/11/6224492045812391804`
  * Method: `GET`
  * Parameter: ``
  * Attack: ``
  * Evidence: `404`
  * Other Info: ``
* URL: http://localhost:3221/pagos/8898887783885292306
  * Node Name: `http://localhost:3221/pagos/8898887783885292306`
  * Method: `GET`
  * Parameter: ``
  * Attack: ``
  * Evidence: `400`
  * Other Info: ``
* URL: http://localhost:3221/tramites
  * Node Name: `http://localhost:3221/tramites`
  * Method: `GET`
  * Parameter: ``
  * Attack: ``
  * Evidence: `403`
  * Other Info: ``
* URL: http://localhost:3221/tramites/
  * Node Name: `http://localhost:3221/tramites/`
  * Method: `GET`
  * Parameter: ``
  * Attack: ``
  * Evidence: `403`
  * Other Info: ``
* URL: http://localhost:3221/tramites/6092156364152895114
  * Node Name: `http://localhost:3221/tramites/6092156364152895114`
  * Method: `GET`
  * Parameter: ``
  * Attack: ``
  * Evidence: `404`
  * Other Info: ``
* URL: http://localhost:3221/tramites/TRA-2420002-970E0C14
  * Node Name: `http://localhost:3221/tramites/TRA-2420002-970E0C14`
  * Method: `GET`
  * Parameter: ``
  * Attack: ``
  * Evidence: `404`
  * Other Info: ``
* URL: http://localhost:3221/tramites/TRA-2420002-970E0C14/
  * Node Name: `http://localhost:3221/tramites/TRA-2420002-970E0C14/`
  * Method: `GET`
  * Parameter: ``
  * Attack: ``
  * Evidence: `404`
  * Other Info: ``
* URL: http://localhost:3221/tramites/TRA-2420002-970E0C14/556370188215499165
  * Node Name: `http://localhost:3221/tramites/TRA-2420002-970E0C14/556370188215499165`
  * Method: `GET`
  * Parameter: ``
  * Attack: ``
  * Evidence: `404`
  * Other Info: ``
* URL: http://localhost:3221/tramites/TRA-2420002-970E0C14/documento
  * Node Name: `http://localhost:3221/tramites/TRA-2420002-970E0C14/documento`
  * Method: `GET`
  * Parameter: ``
  * Attack: ``
  * Evidence: `404`
  * Other Info: ``
* URL: http://localhost:3221/tramites/TRA-2420002-970E0C14/documento/
  * Node Name: `http://localhost:3221/tramites/TRA-2420002-970E0C14/documento/`
  * Method: `GET`
  * Parameter: ``
  * Attack: ``
  * Evidence: `404`
  * Other Info: ``
* URL: http://localhost:3221/usuarios
  * Node Name: `http://localhost:3221/usuarios`
  * Method: `GET`
  * Parameter: ``
  * Attack: ``
  * Evidence: `403`
  * Other Info: ``
* URL: http://localhost:3221/usuarios/
  * Node Name: `http://localhost:3221/usuarios/`
  * Method: `GET`
  * Parameter: ``
  * Attack: ``
  * Evidence: `403`
  * Other Info: ``
* URL: http://localhost:3221/usuarios/3290211403571894607
  * Node Name: `http://localhost:3221/usuarios/3290211403571894607`
  * Method: `GET`
  * Parameter: ``
  * Attack: ``
  * Evidence: `404`
  * Other Info: ``
* URL: http://localhost:3221/usuarios/7ae44410-9ebf-405a-b810-49402a0e5254
  * Node Name: `http://localhost:3221/usuarios/7ae44410-9ebf-405a-b810-49402a0e5254 ()({confirmacion,activo,roles:[]})`
  * Method: `PATCH`
  * Parameter: ``
  * Attack: ``
  * Evidence: `403`
  * Other Info: ``
* URL: http://localhost:3221/usuarios/7ae44410-9ebf-405a-b810-49402a0e5254/
  * Node Name: `http://localhost:3221/usuarios/7ae44410-9ebf-405a-b810-49402a0e5254/ ()({confirmacion,activo,roles:[]})`
  * Method: `PATCH`
  * Parameter: ``
  * Attack: ``
  * Evidence: `403`
  * Other Info: ``
* URL: http://localhost:3221/alumnos/2420002/becas
  * Node Name: `http://localhost:3221/alumnos/2420002/becas ()({importe,concepto})`
  * Method: `POST`
  * Parameter: ``
  * Attack: ``
  * Evidence: `403`
  * Other Info: ``
* URL: http://localhost:3221/alumnos/2420002/becas/
  * Node Name: `http://localhost:3221/alumnos/2420002/becas/ ()({importe,concepto})`
  * Method: `POST`
  * Parameter: ``
  * Attack: ``
  * Evidence: `403`
  * Other Info: ``
* URL: http://localhost:3221/computeMetadata/v1/
  * Node Name: `http://localhost:3221/computeMetadata/v1/ ()({importe,concepto})`
  * Method: `POST`
  * Parameter: ``
  * Attack: ``
  * Evidence: `404`
  * Other Info: ``
* URL: http://localhost:3221/latest/meta-data/
  * Node Name: `http://localhost:3221/latest/meta-data/ ()({importe,concepto})`
  * Method: `POST`
  * Parameter: ``
  * Attack: ``
  * Evidence: `404`
  * Other Info: ``
* URL: http://localhost:3221/metadata/instance
  * Node Name: `http://localhost:3221/metadata/instance ()({importe,concepto})`
  * Method: `POST`
  * Parameter: ``
  * Attack: ``
  * Evidence: `404`
  * Other Info: ``
* URL: http://localhost:3221/metadata/v1
  * Node Name: `http://localhost:3221/metadata/v1 ()({importe,concepto})`
  * Method: `POST`
  * Parameter: ``
  * Attack: ``
  * Evidence: `404`
  * Other Info: ``
* URL: http://localhost:3221/opc/v1/instance/
  * Node Name: `http://localhost:3221/opc/v1/instance/ ()({importe,concepto})`
  * Method: `POST`
  * Parameter: ``
  * Attack: ``
  * Evidence: `404`
  * Other Info: ``
* URL: http://localhost:3221/opc/v2/instance/
  * Node Name: `http://localhost:3221/opc/v2/instance/ ()({importe,concepto})`
  * Method: `POST`
  * Parameter: ``
  * Attack: ``
  * Evidence: `404`
  * Other Info: ``
* URL: http://localhost:3221/openstack/latest/meta_data.json
  * Node Name: `http://localhost:3221/openstack/latest/meta_data.json ()({importe,concepto})`
  * Method: `POST`
  * Parameter: ``
  * Attack: ``
  * Evidence: `404`
  * Other Info: ``
* URL: http://localhost:3221/pagos/11/simulacion
  * Node Name: `http://localhost:3221/pagos/11/simulacion ()({resultado})`
  * Method: `POST`
  * Parameter: ``
  * Attack: ``
  * Evidence: `400`
  * Other Info: ``
* URL: http://localhost:3221/pagos/11/simulacion
  * Node Name: `http://localhost:3221/pagos/11/simulacion ()({resultado})`
  * Method: `POST`
  * Parameter: ``
  * Attack: ``
  * Evidence: `404`
  * Other Info: ``
* URL: http://localhost:3221/pagos/11/simulacion/
  * Node Name: `http://localhost:3221/pagos/11/simulacion/ ()({resultado})`
  * Method: `POST`
  * Parameter: ``
  * Attack: ``
  * Evidence: `404`
  * Other Info: ``
* URL: http://localhost:3221/tramites/TRA-2420002-970E0C14/emision
  * Node Name: `http://localhost:3221/tramites/TRA-2420002-970E0C14/emision`
  * Method: `POST`
  * Parameter: ``
  * Attack: ``
  * Evidence: `403`
  * Other Info: ``
* URL: http://localhost:3221/tramites/TRA-2420002-970E0C14/emision/
  * Node Name: `http://localhost:3221/tramites/TRA-2420002-970E0C14/emision/`
  * Method: `POST`
  * Parameter: ``
  * Attack: ``
  * Evidence: `403`
  * Other Info: ``
* URL: http://localhost:3221/tramites/TRA-2420002-970E0C14/proceso
  * Node Name: `http://localhost:3221/tramites/TRA-2420002-970E0C14/proceso`
  * Method: `POST`
  * Parameter: ``
  * Attack: ``
  * Evidence: `403`
  * Other Info: ``
* URL: http://localhost:3221/tramites/TRA-2420002-970E0C14/proceso/
  * Node Name: `http://localhost:3221/tramites/TRA-2420002-970E0C14/proceso/`
  * Method: `POST`
  * Parameter: ``
  * Attack: ``
  * Evidence: `403`
  * Other Info: ``
* URL: http://localhost:3221/tramites/TRA-2420002-970E0C14/rechazo
  * Node Name: `http://localhost:3221/tramites/TRA-2420002-970E0C14/rechazo ()({motivo})`
  * Method: `POST`
  * Parameter: ``
  * Attack: ``
  * Evidence: `403`
  * Other Info: ``
* URL: http://localhost:3221/tramites/TRA-2420002-970E0C14/rechazo/
  * Node Name: `http://localhost:3221/tramites/TRA-2420002-970E0C14/rechazo/ ()({motivo})`
  * Method: `POST`
  * Parameter: ``
  * Attack: ``
  * Evidence: `403`
  * Other Info: ``
* URL: http://localhost:3221/alumnos/2420002/cuenta
  * Node Name: `http://localhost:3221/alumnos/2420002/cuenta ()({correo})`
  * Method: `PUT`
  * Parameter: ``
  * Attack: ``
  * Evidence: `403`
  * Other Info: ``
* URL: http://localhost:3221/alumnos/2420002/cuenta/
  * Node Name: `http://localhost:3221/alumnos/2420002/cuenta/ ()({correo})`
  * Method: `PUT`
  * Parameter: ``
  * Attack: ``
  * Evidence: `403`
  * Other Info: ``
* URL: http://localhost:3221/alumnos/2420002/estatus
  * Node Name: `http://localhost:3221/alumnos/2420002/estatus ()({estatus})`
  * Method: `PUT`
  * Parameter: ``
  * Attack: ``
  * Evidence: `403`
  * Other Info: ``
* URL: http://localhost:3221/alumnos/2420002/estatus/
  * Node Name: `http://localhost:3221/alumnos/2420002/estatus/ ()({estatus})`
  * Method: `PUT`
  * Parameter: ``
  * Attack: ``
  * Evidence: `403`
  * Other Info: ``
* URL: http://localhost:3221/alumnos/2420002/facultad
  * Node Name: `http://localhost:3221/alumnos/2420002/facultad ()({facultadClave})`
  * Method: `PUT`
  * Parameter: ``
  * Attack: ``
  * Evidence: `403`
  * Other Info: ``
* URL: http://localhost:3221/alumnos/2420002/facultad/
  * Node Name: `http://localhost:3221/alumnos/2420002/facultad/ ()({facultadClave})`
  * Method: `PUT`
  * Parameter: ``
  * Attack: ``
  * Evidence: `403`
  * Other Info: ``
* URL: http://localhost:3221/inscripciones/INS-2026B-2420002/grupos
  * Node Name: `http://localhost:3221/inscripciones/INS-2026B-2420002/grupos ()({grupos:[]})`
  * Method: `PUT`
  * Parameter: ``
  * Attack: ``
  * Evidence: `400`
  * Other Info: ``
* URL: http://localhost:3221/inscripciones/INS-2026B-2420002/grupos
  * Node Name: `http://localhost:3221/inscripciones/INS-2026B-2420002/grupos ()({grupos:[{}]})`
  * Method: `PUT`
  * Parameter: ``
  * Attack: ``
  * Evidence: `404`
  * Other Info: ``
* URL: http://localhost:3221/inscripciones/INS-2026B-2420002/grupos/
  * Node Name: `http://localhost:3221/inscripciones/INS-2026B-2420002/grupos/ ()({grupos:[{}]})`
  * Method: `PUT`
  * Parameter: ``
  * Attack: ``
  * Evidence: `404`
  * Other Info: ``


Instances: 75

### Solution



### Reference



#### CWE Id: [ 388 ](https://cwe.mitre.org/data/definitions/388.html)


#### WASC Id: 20

#### Source ID: 4

### [ Non-Storable Content ](https://www.zaproxy.org/docs/alerts/10049/)



##### Informational (Medium)

### Description

The response contents are not storable by caching components such as proxy servers. If the response does not contain sensitive, personal or user-specific information, it may benefit from being stored and cached, to improve performance.

* URL: http://localhost:3221/alumnos/2420002
  * Node Name: `http://localhost:3221/alumnos/2420002`
  * Method: `GET`
  * Parameter: ``
  * Attack: ``
  * Evidence: `no-store`
  * Other Info: ``
* URL: http://localhost:3221/alumnos/2420002/calificaciones
  * Node Name: `http://localhost:3221/alumnos/2420002/calificaciones`
  * Method: `GET`
  * Parameter: ``
  * Attack: ``
  * Evidence: `no-store`
  * Other Info: ``
* URL: http://localhost:3221/alumnos/2420002/cuenta
  * Node Name: `http://localhost:3221/alumnos/2420002/cuenta`
  * Method: `GET`
  * Parameter: ``
  * Attack: ``
  * Evidence: `no-store`
  * Other Info: ``
* URL: http://localhost:3221/alumnos/2420002/becas
  * Node Name: `http://localhost:3221/alumnos/2420002/becas ()({importe,concepto})`
  * Method: `POST`
  * Parameter: ``
  * Attack: ``
  * Evidence: `no-store`
  * Other Info: ``
* URL: http://localhost:3221/alumnos/2420002/cuenta
  * Node Name: `http://localhost:3221/alumnos/2420002/cuenta ()({correo})`
  * Method: `PUT`
  * Parameter: ``
  * Attack: ``
  * Evidence: `PUT `
  * Other Info: ``

Instances: Systemic


### Solution

The content may be marked as storable by ensuring that the following conditions are satisfied:
The request method must be understood by the cache and defined as being cacheable ("GET", "HEAD", and "POST" are currently defined as cacheable)
The response status code must be understood by the cache (one of the 1XX, 2XX, 3XX, 4XX, or 5XX response classes are generally understood)
The "no-store" cache directive must not appear in the request or response header fields
For caching by "shared" caches such as "proxy" caches, the "private" response directive must not appear in the response
For caching by "shared" caches such as "proxy" caches, the "Authorization" header field must not appear in the request, unless the response explicitly allows it (using one of the "must-revalidate", "public", or "s-maxage" Cache-Control response directives)
In addition to the conditions above, at least one of the following conditions must also be satisfied by the response:
It must contain an "Expires" header field
It must contain a "max-age" response directive
For "shared" caches such as "proxy" caches, it must contain a "s-maxage" response directive
It must contain a "Cache Control Extension" that allows it to be cached
It must have a status code that is defined as cacheable by default (200, 203, 204, 206, 300, 301, 404, 405, 410, 414, 501).

### Reference


* [ https://datatracker.ietf.org/doc/html/rfc7234 ](https://datatracker.ietf.org/doc/html/rfc7234)
* [ https://datatracker.ietf.org/doc/html/rfc7231 ](https://datatracker.ietf.org/doc/html/rfc7231)
* [ https://www.w3.org/Protocols/rfc2616/rfc2616-sec13.html ](https://www.w3.org/Protocols/rfc2616/rfc2616-sec13.html)


#### CWE Id: [ 524 ](https://cwe.mitre.org/data/definitions/524.html)


#### WASC Id: 13

#### Source ID: 3


