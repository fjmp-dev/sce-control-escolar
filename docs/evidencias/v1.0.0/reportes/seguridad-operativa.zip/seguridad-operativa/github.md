## Revision de accesos 2026-11
### Colaboradores y permiso
- samuel0rtiz: write
- fjmp-dev: admin
### Invitaciones pendientes
{"message":"Resource not accessible by integration","documentation_url":"https://docs.github.com/rest/collaborators/invitations#list-repository-invitations","status":"403"}(sin permiso del GITHUB_TOKEN: lo revisa FJMP con gh)
### Ambientes y sus reglas
- piloto: revisores fjmp-dev; branch_policy
- staging: revisores fjmp-dev
### Llaves de despliegue
{"message":"Resource not accessible by integration","documentation_url":"https://docs.github.com/rest/deploy-keys/deploy-keys#list-deploy-keys","status":"403"}(sin permiso del GITHUB_TOKEN: lo revisa FJMP con gh)
### Proteccion de develop y main
{"message":"Resource not accessible by integration","documentation_url":"https://docs.github.com/rest/branches/branch-protection#get-branch-protection","status":"403"}(sin permiso del GITHUB_TOKEN: lo revisa FJMP con gh)
{"message":"Resource not accessible by integration","documentation_url":"https://docs.github.com/rest/branches/branch-protection#get-branch-protection","status":"403"}(sin permiso del GITHUB_TOKEN: lo revisa FJMP con gh)
### Base de datos
- base: rechaza otra direccion, sin TLS, TLS 1.1 y superusuario por red; acepta TLS verificado
- roles con LOGIN: postgres por socket, sce_app y sce_monitor, sin atributos de mas
- pgAudit: DDL registrado
- Asientos de bitacora muestreados: 51 (artefacto)
```
       rol       | activas | inactivas 
-----------------+---------+-----------
 administrador   |       1 |         0
 alumno          |       4 |         0
 caja            |       1 |         0
 control_escolar |       1 |         0
 coordinacion    |       1 |         0
 direccion       |       1 |         0
 profesor        |       3 |         1
(7 rows)

```
