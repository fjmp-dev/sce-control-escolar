# ZAP Scanning Report

ZAP by [Checkmarx](https://checkmarx.com/).


## Summary of Alerts

| Risk Level | Number of Alerts |
| --- | --- |
| High | 0 |
| Medium | 0 |
| Low | 0 |
| Informational | 3 |




## Insights

| Level | Reason | Site | Description | Statistic |
| --- | --- | --- | --- | --- |
| Medium | Exceeded High | http://localhost:3001 | Percentage of responses with status code 4xx | 97 % |
| Info | Informational | http://localhost:3001 | Percentage of responses with status code 2xx | 2 % |
| Info | Informational | http://localhost:3001 | Percentage of endpoints with content type application/json | 100 % |
| Info | Informational | http://localhost:3001 | Percentage of endpoints with method DELETE | 1 % |
| Info | Informational | http://localhost:3001 | Percentage of endpoints with method GET | 59 % |
| Info | Informational | http://localhost:3001 | Percentage of endpoints with method PATCH | 1 % |
| Info | Informational | http://localhost:3001 | Percentage of endpoints with method POST | 30 % |
| Info | Informational | http://localhost:3001 | Percentage of endpoints with method PUT | 7 % |
| Info | Informational | http://localhost:3001 | Count of total endpoints | 168    |







## Alerts

| Name | Risk Level | Number of Instances |
| --- | --- | --- |
| A Client Error response code was returned by the server | Informational | 164 |
| Non-Storable Content | Informational | Systemic |
| Session Management Response Identified | Informational | 1 |




## Alert Detail



### [ A Client Error response code was returned by the server ](https://www.zaproxy.org/docs/alerts/100000/)



##### Informational (High)

### Description

A response code of 400 was returned by the server.
This may indicate that the application is failing to handle unexpected input correctly.
Raised by the 'Alert on HTTP Response Code Error' script

* URL: http://localhost:3001/materias/ISW-101/prerrequisitos/ISW-101
  * Node Name: `http://localhost:3001/materias/ISW-101/prerrequisitos/ISW-101`
  * Method: `DELETE`
  * Parameter: ``
  * Attack: ``
  * Evidence: `404`
  * Other Info: ``
* URL: http://localhost:3001/materias/ISW-101/prerrequisitos/ISW-101/
  * Node Name: `http://localhost:3001/materias/ISW-101/prerrequisitos/ISW-101/`
  * Method: `DELETE`
  * Parameter: ``
  * Attack: ``
  * Evidence: `404`
  * Other Info: ``
* URL: http://localhost:3001
  * Node Name: `http://localhost:3001`
  * Method: `GET`
  * Parameter: ``
  * Attack: ``
  * Evidence: `404`
  * Other Info: ``
* URL: http://localhost:3001/
  * Node Name: `http://localhost:3001/`
  * Method: `GET`
  * Parameter: ``
  * Attack: ``
  * Evidence: `404`
  * Other Info: ``
* URL: http://localhost:3001/7375522383289192468
  * Node Name: `http://localhost:3001/7375522383289192468`
  * Method: `GET`
  * Parameter: ``
  * Attack: ``
  * Evidence: `404`
  * Other Info: ``
* URL: http://localhost:3001/alumnos%3F=
  * Node Name: `http://localhost:3001/alumnos`
  * Method: `GET`
  * Parameter: ``
  * Attack: ``
  * Evidence: `400`
  * Other Info: ``
* URL: http://localhost:3001/alumnos%3Fbuscar=%2523set%2528%2524engine%253D%2522%2522%2529%250A%2523set%2528%2524proc%253D%2524engine.getClass%2528%2529.forName%2528%2522java.lang.Runtime%2522%2529.getRuntime%2528%2529.exec%2528%2522sleep+15%2522%2529%2529%250A%2523set%2528%2524null%253D%2524proc.waitFor%2528%2529%2529%250A%2524%257Bnull%257D
  * Node Name: `http://localhost:3001/alumnos (buscar)`
  * Method: `GET`
  * Parameter: ``
  * Attack: ``
  * Evidence: `400`
  * Other Info: ``
* URL: http://localhost:3001/alumnos/2420001/750568663329125816
  * Node Name: `http://localhost:3001/alumnos/2420001/750568663329125816`
  * Method: `GET`
  * Parameter: ``
  * Attack: ``
  * Evidence: `404`
  * Other Info: ``
* URL: http://localhost:3001/alumnos/2420001/actuator/health
  * Node Name: `http://localhost:3001/alumnos/2420001/actuator/health`
  * Method: `GET`
  * Parameter: ``
  * Attack: ``
  * Evidence: `404`
  * Other Info: ``
* URL: http://localhost:3001/alumnos/2420001/cuenta
  * Node Name: `http://localhost:3001/alumnos/2420001/cuenta`
  * Method: `GET`
  * Parameter: ``
  * Attack: ``
  * Evidence: `403`
  * Other Info: ``
* URL: http://localhost:3001/alumnos/2420001/cuenta/
  * Node Name: `http://localhost:3001/alumnos/2420001/cuenta/`
  * Method: `GET`
  * Parameter: ``
  * Attack: ``
  * Evidence: `403`
  * Other Info: ``
* URL: http://localhost:3001/alumnos/5528786454683119341
  * Node Name: `http://localhost:3001/alumnos/5528786454683119341`
  * Method: `GET`
  * Parameter: ``
  * Attack: ``
  * Evidence: `400`
  * Other Info: ``
* URL: http://localhost:3001/alumnos/actual
  * Node Name: `http://localhost:3001/alumnos/actual`
  * Method: `GET`
  * Parameter: ``
  * Attack: ``
  * Evidence: `404`
  * Other Info: ``
* URL: http://localhost:3001/alumnos/actual/
  * Node Name: `http://localhost:3001/alumnos/actual/`
  * Method: `GET`
  * Parameter: ``
  * Attack: ``
  * Evidence: `404`
  * Other Info: ``
* URL: http://localhost:3001/alumnos/actual/4222769602339026810
  * Node Name: `http://localhost:3001/alumnos/actual/4222769602339026810`
  * Method: `GET`
  * Parameter: ``
  * Attack: ``
  * Evidence: `404`
  * Other Info: ``
* URL: http://localhost:3001/alumnos/actual/calificaciones
  * Node Name: `http://localhost:3001/alumnos/actual/calificaciones`
  * Method: `GET`
  * Parameter: ``
  * Attack: ``
  * Evidence: `404`
  * Other Info: ``
* URL: http://localhost:3001/alumnos/actual/calificaciones/
  * Node Name: `http://localhost:3001/alumnos/actual/calificaciones/`
  * Method: `GET`
  * Parameter: ``
  * Attack: ``
  * Evidence: `404`
  * Other Info: ``
* URL: http://localhost:3001/alumnos/actual/cuenta
  * Node Name: `http://localhost:3001/alumnos/actual/cuenta`
  * Method: `GET`
  * Parameter: ``
  * Attack: ``
  * Evidence: `404`
  * Other Info: ``
* URL: http://localhost:3001/alumnos/actual/cuenta/
  * Node Name: `http://localhost:3001/alumnos/actual/cuenta/`
  * Method: `GET`
  * Parameter: ``
  * Attack: ``
  * Evidence: `404`
  * Other Info: ``
* URL: http://localhost:3001/alumnos/actual/inscripciones
  * Node Name: `http://localhost:3001/alumnos/actual/inscripciones`
  * Method: `GET`
  * Parameter: ``
  * Attack: ``
  * Evidence: `404`
  * Other Info: ``
* URL: http://localhost:3001/alumnos/actual/inscripciones/
  * Node Name: `http://localhost:3001/alumnos/actual/inscripciones/`
  * Method: `GET`
  * Parameter: ``
  * Attack: ``
  * Evidence: `404`
  * Other Info: ``
* URL: http://localhost:3001/alumnos/actual/tramites
  * Node Name: `http://localhost:3001/alumnos/actual/tramites`
  * Method: `GET`
  * Parameter: ``
  * Attack: ``
  * Evidence: `404`
  * Other Info: ``
* URL: http://localhost:3001/alumnos/actual/tramites/
  * Node Name: `http://localhost:3001/alumnos/actual/tramites/`
  * Method: `GET`
  * Parameter: ``
  * Attack: ``
  * Evidence: `404`
  * Other Info: ``
* URL: http://localhost:3001/calificaciones
  * Node Name: `http://localhost:3001/calificaciones`
  * Method: `GET`
  * Parameter: ``
  * Attack: ``
  * Evidence: `404`
  * Other Info: ``
* URL: http://localhost:3001/calificaciones/
  * Node Name: `http://localhost:3001/calificaciones/`
  * Method: `GET`
  * Parameter: ``
  * Attack: ``
  * Evidence: `404`
  * Other Info: ``
* URL: http://localhost:3001/calificaciones/1.2
  * Node Name: `http://localhost:3001/calificaciones/1.2`
  * Method: `GET`
  * Parameter: ``
  * Attack: ``
  * Evidence: `404`
  * Other Info: ``
* URL: http://localhost:3001/calificaciones/1.2/
  * Node Name: `http://localhost:3001/calificaciones/1.2/`
  * Method: `GET`
  * Parameter: ``
  * Attack: ``
  * Evidence: `404`
  * Other Info: ``
* URL: http://localhost:3001/calificaciones/1.2/6837343891518342261
  * Node Name: `http://localhost:3001/calificaciones/1.2/6837343891518342261`
  * Method: `GET`
  * Parameter: ``
  * Attack: ``
  * Evidence: `404`
  * Other Info: ``
* URL: http://localhost:3001/calificaciones/2294023479420151503
  * Node Name: `http://localhost:3001/calificaciones/2294023479420151503`
  * Method: `GET`
  * Parameter: ``
  * Attack: ``
  * Evidence: `404`
  * Other Info: ``
* URL: http://localhost:3001/documentos
  * Node Name: `http://localhost:3001/documentos`
  * Method: `GET`
  * Parameter: ``
  * Attack: ``
  * Evidence: `404`
  * Other Info: ``
* URL: http://localhost:3001/documentos/
  * Node Name: `http://localhost:3001/documentos/`
  * Method: `GET`
  * Parameter: ``
  * Attack: ``
  * Evidence: `404`
  * Other Info: ``
* URL: http://localhost:3001/documentos/3715947024913540383
  * Node Name: `http://localhost:3001/documentos/3715947024913540383`
  * Method: `GET`
  * Parameter: ``
  * Attack: ``
  * Evidence: `404`
  * Other Info: ``
* URL: http://localhost:3001/documentos/TRA-2420001-1A2B3C4D
  * Node Name: `http://localhost:3001/documentos/TRA-2420001-1A2B3C4D`
  * Method: `GET`
  * Parameter: ``
  * Attack: ``
  * Evidence: `404`
  * Other Info: ``
* URL: http://localhost:3001/documentos/TRA-2420001-1A2B3C4D/
  * Node Name: `http://localhost:3001/documentos/TRA-2420001-1A2B3C4D/`
  * Method: `GET`
  * Parameter: ``
  * Attack: ``
  * Evidence: `404`
  * Other Info: ``
* URL: http://localhost:3001/grupos
  * Node Name: `http://localhost:3001/grupos`
  * Method: `GET`
  * Parameter: ``
  * Attack: ``
  * Evidence: `400`
  * Other Info: ``
* URL: http://localhost:3001/grupos%3Fperiodo=http%253A%252F%252Fwww.google.com%252F
  * Node Name: `http://localhost:3001/grupos (periodo)`
  * Method: `GET`
  * Parameter: ``
  * Attack: ``
  * Evidence: `400`
  * Other Info: ``
* URL: http://localhost:3001/grupos/
  * Node Name: `http://localhost:3001/grupos/`
  * Method: `GET`
  * Parameter: ``
  * Attack: ``
  * Evidence: `400`
  * Other Info: ``
* URL: http://localhost:3001/grupos/1.2
  * Node Name: `http://localhost:3001/grupos/1.2`
  * Method: `GET`
  * Parameter: ``
  * Attack: ``
  * Evidence: `404`
  * Other Info: ``
* URL: http://localhost:3001/grupos/1.2/
  * Node Name: `http://localhost:3001/grupos/1.2/`
  * Method: `GET`
  * Parameter: ``
  * Attack: ``
  * Evidence: `404`
  * Other Info: ``
* URL: http://localhost:3001/grupos/1.2/3458904355330768752
  * Node Name: `http://localhost:3001/grupos/1.2/3458904355330768752`
  * Method: `GET`
  * Parameter: ``
  * Attack: ``
  * Evidence: `404`
  * Other Info: ``
* URL: http://localhost:3001/grupos/1.2/calificaciones
  * Node Name: `http://localhost:3001/grupos/1.2/calificaciones`
  * Method: `GET`
  * Parameter: ``
  * Attack: ``
  * Evidence: `403`
  * Other Info: ``
* URL: http://localhost:3001/grupos/1.2/calificaciones/
  * Node Name: `http://localhost:3001/grupos/1.2/calificaciones/`
  * Method: `GET`
  * Parameter: ``
  * Attack: ``
  * Evidence: `403`
  * Other Info: ``
* URL: http://localhost:3001/grupos/1231003309864710477
  * Node Name: `http://localhost:3001/grupos/1231003309864710477`
  * Method: `GET`
  * Parameter: ``
  * Attack: ``
  * Evidence: `404`
  * Other Info: ``
* URL: http://localhost:3001/grupos/choques%3Fgrupos=%255B1,2%255D
  * Node Name: `http://localhost:3001/grupos/choques (grupos)`
  * Method: `GET`
  * Parameter: ``
  * Attack: ``
  * Evidence: `400`
  * Other Info: ``
* URL: http://localhost:3001/grupos/choques/
  * Node Name: `http://localhost:3001/grupos/choques/`
  * Method: `GET`
  * Parameter: ``
  * Attack: ``
  * Evidence: `400`
  * Other Info: ``
* URL: http://localhost:3001/inscripciones
  * Node Name: `http://localhost:3001/inscripciones`
  * Method: `GET`
  * Parameter: ``
  * Attack: ``
  * Evidence: `404`
  * Other Info: ``
* URL: http://localhost:3001/inscripciones/
  * Node Name: `http://localhost:3001/inscripciones/`
  * Method: `GET`
  * Parameter: ``
  * Attack: ``
  * Evidence: `404`
  * Other Info: ``
* URL: http://localhost:3001/inscripciones/1107562154565213995
  * Node Name: `http://localhost:3001/inscripciones/1107562154565213995`
  * Method: `GET`
  * Parameter: ``
  * Attack: ``
  * Evidence: `404`
  * Other Info: ``
* URL: http://localhost:3001/inscripciones/ISW-101
  * Node Name: `http://localhost:3001/inscripciones/ISW-101`
  * Method: `GET`
  * Parameter: ``
  * Attack: ``
  * Evidence: `404`
  * Other Info: ``
* URL: http://localhost:3001/inscripciones/ISW-101/
  * Node Name: `http://localhost:3001/inscripciones/ISW-101/`
  * Method: `GET`
  * Parameter: ``
  * Attack: ``
  * Evidence: `404`
  * Other Info: ``
* URL: http://localhost:3001/inscripciones/ISW-101/2935865712789377768
  * Node Name: `http://localhost:3001/inscripciones/ISW-101/2935865712789377768`
  * Method: `GET`
  * Parameter: ``
  * Attack: ``
  * Evidence: `404`
  * Other Info: ``
* URL: http://localhost:3001/materias/926826417352637605
  * Node Name: `http://localhost:3001/materias/926826417352637605`
  * Method: `GET`
  * Parameter: ``
  * Attack: ``
  * Evidence: `404`
  * Other Info: ``
* URL: http://localhost:3001/materias/ISW-101
  * Node Name: `http://localhost:3001/materias/ISW-101`
  * Method: `GET`
  * Parameter: ``
  * Attack: ``
  * Evidence: `404`
  * Other Info: ``
* URL: http://localhost:3001/materias/ISW-101/
  * Node Name: `http://localhost:3001/materias/ISW-101/`
  * Method: `GET`
  * Parameter: ``
  * Attack: ``
  * Evidence: `404`
  * Other Info: ``
* URL: http://localhost:3001/materias/ISW-101/7253763230561474861
  * Node Name: `http://localhost:3001/materias/ISW-101/7253763230561474861`
  * Method: `GET`
  * Parameter: ``
  * Attack: ``
  * Evidence: `404`
  * Other Info: ``
* URL: http://localhost:3001/materias/ISW-101/prerrequisitos
  * Node Name: `http://localhost:3001/materias/ISW-101/prerrequisitos`
  * Method: `GET`
  * Parameter: ``
  * Attack: ``
  * Evidence: `404`
  * Other Info: ``
* URL: http://localhost:3001/materias/ISW-101/prerrequisitos/
  * Node Name: `http://localhost:3001/materias/ISW-101/prerrequisitos/`
  * Method: `GET`
  * Parameter: ``
  * Attack: ``
  * Evidence: `404`
  * Other Info: ``
* URL: http://localhost:3001/materias/ISW-101/prerrequisitos/7787525039136173016
  * Node Name: `http://localhost:3001/materias/ISW-101/prerrequisitos/7787525039136173016`
  * Method: `GET`
  * Parameter: ``
  * Attack: ``
  * Evidence: `404`
  * Other Info: ``
* URL: http://localhost:3001/pagos
  * Node Name: `http://localhost:3001/pagos`
  * Method: `GET`
  * Parameter: ``
  * Attack: ``
  * Evidence: `403`
  * Other Info: ``
* URL: http://localhost:3001/pagos%3Ffecha=Tue%2520Nov%252010%252000:00:00%2520UTC%25202026
  * Node Name: `http://localhost:3001/pagos (fecha)`
  * Method: `GET`
  * Parameter: ``
  * Attack: ``
  * Evidence: `403`
  * Other Info: ``
* URL: http://localhost:3001/pagos/
  * Node Name: `http://localhost:3001/pagos/`
  * Method: `GET`
  * Parameter: ``
  * Attack: ``
  * Evidence: `403`
  * Other Info: ``
* URL: http://localhost:3001/pagos/1.2
  * Node Name: `http://localhost:3001/pagos/1.2`
  * Method: `GET`
  * Parameter: ``
  * Attack: ``
  * Evidence: `400`
  * Other Info: ``
* URL: http://localhost:3001/pagos/1.2/
  * Node Name: `http://localhost:3001/pagos/1.2/`
  * Method: `GET`
  * Parameter: ``
  * Attack: ``
  * Evidence: `400`
  * Other Info: ``
* URL: http://localhost:3001/pagos/1.2/6583681103559548928
  * Node Name: `http://localhost:3001/pagos/1.2/6583681103559548928`
  * Method: `GET`
  * Parameter: ``
  * Attack: ``
  * Evidence: `404`
  * Other Info: ``
* URL: http://localhost:3001/pagos/4646212870692853956
  * Node Name: `http://localhost:3001/pagos/4646212870692853956`
  * Method: `GET`
  * Parameter: ``
  * Attack: ``
  * Evidence: `400`
  * Other Info: ``
* URL: http://localhost:3001/periodos/2027A
  * Node Name: `http://localhost:3001/periodos/2027A`
  * Method: `GET`
  * Parameter: ``
  * Attack: ``
  * Evidence: `404`
  * Other Info: ``
* URL: http://localhost:3001/periodos/2027A/
  * Node Name: `http://localhost:3001/periodos/2027A/`
  * Method: `GET`
  * Parameter: ``
  * Attack: ``
  * Evidence: `404`
  * Other Info: ``
* URL: http://localhost:3001/periodos/2027A/1524885399519739226
  * Node Name: `http://localhost:3001/periodos/2027A/1524885399519739226`
  * Method: `GET`
  * Parameter: ``
  * Attack: ``
  * Evidence: `404`
  * Other Info: ``
* URL: http://localhost:3001/periodos/2027A/reporte
  * Node Name: `http://localhost:3001/periodos/2027A/reporte`
  * Method: `GET`
  * Parameter: ``
  * Attack: ``
  * Evidence: `403`
  * Other Info: ``
* URL: http://localhost:3001/periodos/2027A/reporte/
  * Node Name: `http://localhost:3001/periodos/2027A/reporte/`
  * Method: `GET`
  * Parameter: ``
  * Attack: ``
  * Evidence: `403`
  * Other Info: ``
* URL: http://localhost:3001/periodos/7015316252584983175
  * Node Name: `http://localhost:3001/periodos/7015316252584983175`
  * Method: `GET`
  * Parameter: ``
  * Attack: ``
  * Evidence: `404`
  * Other Info: ``
* URL: http://localhost:3001/profesores
  * Node Name: `http://localhost:3001/profesores`
  * Method: `GET`
  * Parameter: ``
  * Attack: ``
  * Evidence: `404`
  * Other Info: ``
* URL: http://localhost:3001/profesores/
  * Node Name: `http://localhost:3001/profesores/`
  * Method: `GET`
  * Parameter: ``
  * Attack: ``
  * Evidence: `404`
  * Other Info: ``
* URL: http://localhost:3001/profesores/5087192834522565370
  * Node Name: `http://localhost:3001/profesores/5087192834522565370`
  * Method: `GET`
  * Parameter: ``
  * Attack: ``
  * Evidence: `404`
  * Other Info: ``
* URL: http://localhost:3001/profesores/actual
  * Node Name: `http://localhost:3001/profesores/actual`
  * Method: `GET`
  * Parameter: ``
  * Attack: ``
  * Evidence: `404`
  * Other Info: ``
* URL: http://localhost:3001/profesores/actual/
  * Node Name: `http://localhost:3001/profesores/actual/`
  * Method: `GET`
  * Parameter: ``
  * Attack: ``
  * Evidence: `404`
  * Other Info: ``
* URL: http://localhost:3001/profesores/actual/3667507527484068418
  * Node Name: `http://localhost:3001/profesores/actual/3667507527484068418`
  * Method: `GET`
  * Parameter: ``
  * Attack: ``
  * Evidence: `404`
  * Other Info: ``
* URL: http://localhost:3001/profesores/actual/grupos
  * Node Name: `http://localhost:3001/profesores/actual/grupos`
  * Method: `GET`
  * Parameter: ``
  * Attack: ``
  * Evidence: `403`
  * Other Info: ``
* URL: http://localhost:3001/profesores/actual/grupos/
  * Node Name: `http://localhost:3001/profesores/actual/grupos/`
  * Method: `GET`
  * Parameter: ``
  * Attack: ``
  * Evidence: `403`
  * Other Info: ``
* URL: http://localhost:3001/sesiones
  * Node Name: `http://localhost:3001/sesiones`
  * Method: `GET`
  * Parameter: ``
  * Attack: ``
  * Evidence: `404`
  * Other Info: ``
* URL: http://localhost:3001/sesiones/
  * Node Name: `http://localhost:3001/sesiones/`
  * Method: `GET`
  * Parameter: ``
  * Attack: ``
  * Evidence: `404`
  * Other Info: ``
* URL: http://localhost:3001/sesiones/8698044845733639767
  * Node Name: `http://localhost:3001/sesiones/8698044845733639767`
  * Method: `GET`
  * Parameter: ``
  * Attack: ``
  * Evidence: `404`
  * Other Info: ``
* URL: http://localhost:3001/sesiones/actual/3649631465557814808
  * Node Name: `http://localhost:3001/sesiones/actual/3649631465557814808`
  * Method: `GET`
  * Parameter: ``
  * Attack: ``
  * Evidence: `404`
  * Other Info: ``
* URL: http://localhost:3001/tramites%3F=
  * Node Name: `http://localhost:3001/tramites`
  * Method: `GET`
  * Parameter: ``
  * Attack: ``
  * Evidence: `400`
  * Other Info: ``
* URL: http://localhost:3001/tramites%3Festado=http%253A%252F%252Fwww.google.com%252F
  * Node Name: `http://localhost:3001/tramites (estado)`
  * Method: `GET`
  * Parameter: ``
  * Attack: ``
  * Evidence: `400`
  * Other Info: ``
* URL: http://localhost:3001/tramites/594809363430761734
  * Node Name: `http://localhost:3001/tramites/594809363430761734`
  * Method: `GET`
  * Parameter: ``
  * Attack: ``
  * Evidence: `404`
  * Other Info: ``
* URL: http://localhost:3001/tramites/TRA-2420001-1A2B3C4D
  * Node Name: `http://localhost:3001/tramites/TRA-2420001-1A2B3C4D`
  * Method: `GET`
  * Parameter: ``
  * Attack: ``
  * Evidence: `404`
  * Other Info: ``
* URL: http://localhost:3001/tramites/TRA-2420001-1A2B3C4D/
  * Node Name: `http://localhost:3001/tramites/TRA-2420001-1A2B3C4D/`
  * Method: `GET`
  * Parameter: ``
  * Attack: ``
  * Evidence: `404`
  * Other Info: ``
* URL: http://localhost:3001/tramites/TRA-2420001-1A2B3C4D/3287381763549201988
  * Node Name: `http://localhost:3001/tramites/TRA-2420001-1A2B3C4D/3287381763549201988`
  * Method: `GET`
  * Parameter: ``
  * Attack: ``
  * Evidence: `404`
  * Other Info: ``
* URL: http://localhost:3001/tramites/TRA-2420001-1A2B3C4D/documento
  * Node Name: `http://localhost:3001/tramites/TRA-2420001-1A2B3C4D/documento`
  * Method: `GET`
  * Parameter: ``
  * Attack: ``
  * Evidence: `404`
  * Other Info: ``
* URL: http://localhost:3001/tramites/TRA-2420001-1A2B3C4D/documento/
  * Node Name: `http://localhost:3001/tramites/TRA-2420001-1A2B3C4D/documento/`
  * Method: `GET`
  * Parameter: ``
  * Attack: ``
  * Evidence: `404`
  * Other Info: ``
* URL: http://localhost:3001/usuarios/8770116817766662941
  * Node Name: `http://localhost:3001/usuarios/8770116817766662941`
  * Method: `GET`
  * Parameter: ``
  * Attack: ``
  * Evidence: `404`
  * Other Info: ``
* URL: http://localhost:3001/usuarios/id
  * Node Name: `http://localhost:3001/usuarios/id ()({confirmacion,activo,roles:[]})`
  * Method: `PATCH`
  * Parameter: ``
  * Attack: ``
  * Evidence: `400`
  * Other Info: ``
* URL: http://localhost:3001/usuarios/id/
  * Node Name: `http://localhost:3001/usuarios/id/ ()({confirmacion,activo,roles:[]})`
  * Method: `PATCH`
  * Parameter: ``
  * Attack: ``
  * Evidence: `400`
  * Other Info: ``
* URL: http://localhost:3001/alumnos
  * Node Name: `http://localhost:3001/alumnos ()({matricula,nombre,facultadClave,fechaIngreso,correo})`
  * Method: `POST`
  * Parameter: ``
  * Attack: ``
  * Evidence: `400`
  * Other Info: ``
* URL: http://localhost:3001/alumnos/
  * Node Name: `http://localhost:3001/alumnos/ ()({matricula,nombre,facultadClave,fechaIngreso,correo})`
  * Method: `POST`
  * Parameter: ``
  * Attack: ``
  * Evidence: `400`
  * Other Info: ``
* URL: http://localhost:3001/alumnos/2420001/becas
  * Node Name: `http://localhost:3001/alumnos/2420001/becas ()({importe,concepto})`
  * Method: `POST`
  * Parameter: ``
  * Attack: ``
  * Evidence: `403`
  * Other Info: ``
* URL: http://localhost:3001/alumnos/2420001/becas/
  * Node Name: `http://localhost:3001/alumnos/2420001/becas/ ()({importe,concepto})`
  * Method: `POST`
  * Parameter: ``
  * Attack: ``
  * Evidence: `403`
  * Other Info: ``
* URL: http://localhost:3001/computeMetadata/v1/
  * Node Name: `http://localhost:3001/computeMetadata/v1/ ()({importe,concepto})`
  * Method: `POST`
  * Parameter: ``
  * Attack: ``
  * Evidence: `404`
  * Other Info: ``
* URL: http://localhost:3001/facultades
  * Node Name: `http://localhost:3001/facultades ()({clave,nombre})`
  * Method: `POST`
  * Parameter: ``
  * Attack: ``
  * Evidence: `400`
  * Other Info: ``
* URL: http://localhost:3001/facultades
  * Node Name: `http://localhost:3001/facultades ()({clave,nombre})`
  * Method: `POST`
  * Parameter: ``
  * Attack: ``
  * Evidence: `409`
  * Other Info: ``
* URL: http://localhost:3001/facultades/
  * Node Name: `http://localhost:3001/facultades/ ()({clave,nombre})`
  * Method: `POST`
  * Parameter: ``
  * Attack: ``
  * Evidence: `409`
  * Other Info: ``
* URL: http://localhost:3001/grupos
  * Node Name: `http://localhost:3001/grupos ()({periodoClave,clave,materiaClave,profesor,cupo,horarios:[{dia,horaInicio,horaFin,aula}]})`
  * Method: `POST`
  * Parameter: ``
  * Attack: ``
  * Evidence: `400`
  * Other Info: ``
* URL: http://localhost:3001/grupos/
  * Node Name: `http://localhost:3001/grupos/ ()({periodoClave,clave,materiaClave,profesor,cupo,horarios:[{dia,horaInicio,horaFin,aula}]})`
  * Method: `POST`
  * Parameter: ``
  * Attack: ``
  * Evidence: `400`
  * Other Info: ``
* URL: http://localhost:3001/inscripciones
  * Node Name: `http://localhost:3001/inscripciones ()({grupos:[],periodoClave})`
  * Method: `POST`
  * Parameter: ``
  * Attack: ``
  * Evidence: `400`
  * Other Info: ``
* URL: http://localhost:3001/inscripciones
  * Node Name: `http://localhost:3001/inscripciones ()({grupos:[{}],periodoClave})`
  * Method: `POST`
  * Parameter: ``
  * Attack: ``
  * Evidence: `400`
  * Other Info: ``
* URL: http://localhost:3001/inscripciones/
  * Node Name: `http://localhost:3001/inscripciones/ ()({grupos:[{}],periodoClave})`
  * Method: `POST`
  * Parameter: ``
  * Attack: ``
  * Evidence: `400`
  * Other Info: ``
* URL: http://localhost:3001/latest/meta-data/
  * Node Name: `http://localhost:3001/latest/meta-data/ ()({importe,concepto})`
  * Method: `POST`
  * Parameter: ``
  * Attack: ``
  * Evidence: `404`
  * Other Info: ``
* URL: http://localhost:3001/materias
  * Node Name: `http://localhost:3001/materias ()({clave,planClave,nombre,creditos})`
  * Method: `POST`
  * Parameter: ``
  * Attack: ``
  * Evidence: `400`
  * Other Info: ``
* URL: http://localhost:3001/materias/
  * Node Name: `http://localhost:3001/materias/ ()({clave,planClave,nombre,creditos})`
  * Method: `POST`
  * Parameter: ``
  * Attack: ``
  * Evidence: `400`
  * Other Info: ``
* URL: http://localhost:3001/materias/ISW-101/prerrequisitos
  * Node Name: `http://localhost:3001/materias/ISW-101/prerrequisitos ()({requiereClave,obligatorio})`
  * Method: `POST`
  * Parameter: ``
  * Attack: ``
  * Evidence: `400`
  * Other Info: ``
* URL: http://localhost:3001/materias/ISW-101/prerrequisitos
  * Node Name: `http://localhost:3001/materias/ISW-101/prerrequisitos ()({requiereClave,obligatorio})`
  * Method: `POST`
  * Parameter: ``
  * Attack: ``
  * Evidence: `409`
  * Other Info: ``
* URL: http://localhost:3001/materias/ISW-101/prerrequisitos/
  * Node Name: `http://localhost:3001/materias/ISW-101/prerrequisitos/ ()({requiereClave,obligatorio})`
  * Method: `POST`
  * Parameter: ``
  * Attack: ``
  * Evidence: `409`
  * Other Info: ``
* URL: http://localhost:3001/metadata/instance
  * Node Name: `http://localhost:3001/metadata/instance ()({importe,concepto})`
  * Method: `POST`
  * Parameter: ``
  * Attack: ``
  * Evidence: `404`
  * Other Info: ``
* URL: http://localhost:3001/metadata/v1
  * Node Name: `http://localhost:3001/metadata/v1 ()({importe,concepto})`
  * Method: `POST`
  * Parameter: ``
  * Attack: ``
  * Evidence: `404`
  * Other Info: ``
* URL: http://localhost:3001/opc/v1/instance/
  * Node Name: `http://localhost:3001/opc/v1/instance/ ()({importe,concepto})`
  * Method: `POST`
  * Parameter: ``
  * Attack: ``
  * Evidence: `404`
  * Other Info: ``
* URL: http://localhost:3001/opc/v2/instance/
  * Node Name: `http://localhost:3001/opc/v2/instance/ ()({importe,concepto})`
  * Method: `POST`
  * Parameter: ``
  * Attack: ``
  * Evidence: `404`
  * Other Info: ``
* URL: http://localhost:3001/openstack/latest/meta_data.json
  * Node Name: `http://localhost:3001/openstack/latest/meta_data.json ()({importe,concepto})`
  * Method: `POST`
  * Parameter: ``
  * Attack: ``
  * Evidence: `404`
  * Other Info: ``
* URL: http://localhost:3001/pagos
  * Node Name: `http://localhost:3001/pagos ()({importe})`
  * Method: `POST`
  * Parameter: ``
  * Attack: ``
  * Evidence: `400`
  * Other Info: ``
* URL: http://localhost:3001/pagos
  * Node Name: `http://localhost:3001/pagos ()({importe})`
  * Method: `POST`
  * Parameter: ``
  * Attack: ``
  * Evidence: `404`
  * Other Info: ``
* URL: http://localhost:3001/pagos/
  * Node Name: `http://localhost:3001/pagos/ ()({importe})`
  * Method: `POST`
  * Parameter: ``
  * Attack: ``
  * Evidence: `404`
  * Other Info: ``
* URL: http://localhost:3001/pagos/1.2/simulacion
  * Node Name: `http://localhost:3001/pagos/1.2/simulacion ()({resultado})`
  * Method: `POST`
  * Parameter: ``
  * Attack: ``
  * Evidence: `400`
  * Other Info: ``
* URL: http://localhost:3001/pagos/1.2/simulacion/
  * Node Name: `http://localhost:3001/pagos/1.2/simulacion/ ()({resultado})`
  * Method: `POST`
  * Parameter: ``
  * Attack: ``
  * Evidence: `400`
  * Other Info: ``
* URL: http://localhost:3001/periodos
  * Node Name: `http://localhost:3001/periodos ()({clave,fechaInicio,fechaFin})`
  * Method: `POST`
  * Parameter: ``
  * Attack: ``
  * Evidence: `400`
  * Other Info: ``
* URL: http://localhost:3001/periodos
  * Node Name: `http://localhost:3001/periodos ()({clave,fechaInicio,fechaFin})`
  * Method: `POST`
  * Parameter: ``
  * Attack: ``
  * Evidence: `409`
  * Other Info: ``
* URL: http://localhost:3001/periodos/
  * Node Name: `http://localhost:3001/periodos/ ()({clave,fechaInicio,fechaFin})`
  * Method: `POST`
  * Parameter: ``
  * Attack: ``
  * Evidence: `400`
  * Other Info: ``
* URL: http://localhost:3001/periodos/2027A/cargos
  * Node Name: `http://localhost:3001/periodos/2027A/cargos ()({importe,concepto})`
  * Method: `POST`
  * Parameter: ``
  * Attack: ``
  * Evidence: `403`
  * Other Info: ``
* URL: http://localhost:3001/periodos/2027A/cargos/
  * Node Name: `http://localhost:3001/periodos/2027A/cargos/ ()({importe,concepto})`
  * Method: `POST`
  * Parameter: ``
  * Attack: ``
  * Evidence: `403`
  * Other Info: ``
* URL: http://localhost:3001/periodos/2027A/cierre
  * Node Name: `http://localhost:3001/periodos/2027A/cierre`
  * Method: `POST`
  * Parameter: ``
  * Attack: ``
  * Evidence: `409`
  * Other Info: ``
* URL: http://localhost:3001/periodos/2027A/cierre/
  * Node Name: `http://localhost:3001/periodos/2027A/cierre/`
  * Method: `POST`
  * Parameter: ``
  * Attack: ``
  * Evidence: `409`
  * Other Info: ``
* URL: http://localhost:3001/periodos/2027A/inicio/
  * Node Name: `http://localhost:3001/periodos/2027A/inicio/`
  * Method: `POST`
  * Parameter: ``
  * Attack: ``
  * Evidence: `409`
  * Other Info: ``
* URL: http://localhost:3001/periodos/2027A/publicacion
  * Node Name: `http://localhost:3001/periodos/2027A/publicacion`
  * Method: `POST`
  * Parameter: ``
  * Attack: ``
  * Evidence: `409`
  * Other Info: ``
* URL: http://localhost:3001/periodos/2027A/publicacion/
  * Node Name: `http://localhost:3001/periodos/2027A/publicacion/`
  * Method: `POST`
  * Parameter: ``
  * Attack: ``
  * Evidence: `409`
  * Other Info: ``
* URL: http://localhost:3001/planes
  * Node Name: `http://localhost:3001/planes ()({clave,facultadClave,creditosTotales,vigenteDesde})`
  * Method: `POST`
  * Parameter: ``
  * Attack: ``
  * Evidence: `400`
  * Other Info: ``
* URL: http://localhost:3001/planes/
  * Node Name: `http://localhost:3001/planes/ ()({clave,facultadClave,creditosTotales,vigenteDesde})`
  * Method: `POST`
  * Parameter: ``
  * Attack: ``
  * Evidence: `400`
  * Other Info: ``
* URL: http://localhost:3001/sesiones
  * Node Name: `http://localhost:3001/sesiones ()({correo,contrasena})`
  * Method: `POST`
  * Parameter: ``
  * Attack: ``
  * Evidence: `400`
  * Other Info: ``
* URL: http://localhost:3001/sesiones/
  * Node Name: `http://localhost:3001/sesiones/ ()({correo,contrasena})`
  * Method: `POST`
  * Parameter: ``
  * Attack: ``
  * Evidence: `400`
  * Other Info: ``
* URL: http://localhost:3001/tramites
  * Node Name: `http://localhost:3001/tramites ()({tipo})`
  * Method: `POST`
  * Parameter: ``
  * Attack: ``
  * Evidence: `400`
  * Other Info: ``
* URL: http://localhost:3001/tramites
  * Node Name: `http://localhost:3001/tramites ()({tipo})`
  * Method: `POST`
  * Parameter: ``
  * Attack: ``
  * Evidence: `404`
  * Other Info: ``
* URL: http://localhost:3001/tramites/
  * Node Name: `http://localhost:3001/tramites/ ()({tipo})`
  * Method: `POST`
  * Parameter: ``
  * Attack: ``
  * Evidence: `404`
  * Other Info: ``
* URL: http://localhost:3001/tramites/TRA-2420001-1A2B3C4D/emision
  * Node Name: `http://localhost:3001/tramites/TRA-2420001-1A2B3C4D/emision`
  * Method: `POST`
  * Parameter: ``
  * Attack: ``
  * Evidence: `404`
  * Other Info: ``
* URL: http://localhost:3001/tramites/TRA-2420001-1A2B3C4D/emision/
  * Node Name: `http://localhost:3001/tramites/TRA-2420001-1A2B3C4D/emision/`
  * Method: `POST`
  * Parameter: ``
  * Attack: ``
  * Evidence: `404`
  * Other Info: ``
* URL: http://localhost:3001/tramites/TRA-2420001-1A2B3C4D/proceso
  * Node Name: `http://localhost:3001/tramites/TRA-2420001-1A2B3C4D/proceso`
  * Method: `POST`
  * Parameter: ``
  * Attack: ``
  * Evidence: `404`
  * Other Info: ``
* URL: http://localhost:3001/tramites/TRA-2420001-1A2B3C4D/proceso/
  * Node Name: `http://localhost:3001/tramites/TRA-2420001-1A2B3C4D/proceso/`
  * Method: `POST`
  * Parameter: ``
  * Attack: ``
  * Evidence: `404`
  * Other Info: ``
* URL: http://localhost:3001/tramites/TRA-2420001-1A2B3C4D/rechazo
  * Node Name: `http://localhost:3001/tramites/TRA-2420001-1A2B3C4D/rechazo ()({motivo})`
  * Method: `POST`
  * Parameter: ``
  * Attack: ``
  * Evidence: `400`
  * Other Info: ``
* URL: http://localhost:3001/tramites/TRA-2420001-1A2B3C4D/rechazo
  * Node Name: `http://localhost:3001/tramites/TRA-2420001-1A2B3C4D/rechazo ()({motivo})`
  * Method: `POST`
  * Parameter: ``
  * Attack: ``
  * Evidence: `404`
  * Other Info: ``
* URL: http://localhost:3001/tramites/TRA-2420001-1A2B3C4D/rechazo/
  * Node Name: `http://localhost:3001/tramites/TRA-2420001-1A2B3C4D/rechazo/ ()({motivo})`
  * Method: `POST`
  * Parameter: ``
  * Attack: ``
  * Evidence: `404`
  * Other Info: ``
* URL: http://localhost:3001/usuarios
  * Node Name: `http://localhost:3001/usuarios ()({confirmacion,correo,contrasena,roles:[]})`
  * Method: `POST`
  * Parameter: ``
  * Attack: ``
  * Evidence: `400`
  * Other Info: ``
* URL: http://localhost:3001/usuarios/
  * Node Name: `http://localhost:3001/usuarios/ ()({confirmacion,correo,contrasena,roles:[]})`
  * Method: `POST`
  * Parameter: ``
  * Attack: ``
  * Evidence: `400`
  * Other Info: ``
* URL: http://localhost:3001/alumnos/2420001/cuenta
  * Node Name: `http://localhost:3001/alumnos/2420001/cuenta ()({correo})`
  * Method: `PUT`
  * Parameter: ``
  * Attack: ``
  * Evidence: `400`
  * Other Info: ``
* URL: http://localhost:3001/alumnos/2420001/cuenta/
  * Node Name: `http://localhost:3001/alumnos/2420001/cuenta/ ()({correo})`
  * Method: `PUT`
  * Parameter: ``
  * Attack: ``
  * Evidence: `400`
  * Other Info: ``
* URL: http://localhost:3001/alumnos/2420001/estatus
  * Node Name: `http://localhost:3001/alumnos/2420001/estatus ()({estatus})`
  * Method: `PUT`
  * Parameter: ``
  * Attack: ``
  * Evidence: `400`
  * Other Info: ``
* URL: http://localhost:3001/alumnos/2420001/estatus
  * Node Name: `http://localhost:3001/alumnos/2420001/estatus ()({estatus})`
  * Method: `PUT`
  * Parameter: ``
  * Attack: ``
  * Evidence: `409`
  * Other Info: ``
* URL: http://localhost:3001/alumnos/2420001/estatus/
  * Node Name: `http://localhost:3001/alumnos/2420001/estatus/ ()({estatus})`
  * Method: `PUT`
  * Parameter: ``
  * Attack: ``
  * Evidence: `409`
  * Other Info: ``
* URL: http://localhost:3001/alumnos/2420001/facultad
  * Node Name: `http://localhost:3001/alumnos/2420001/facultad ()({facultadClave})`
  * Method: `PUT`
  * Parameter: ``
  * Attack: ``
  * Evidence: `400`
  * Other Info: ``
* URL: http://localhost:3001/alumnos/2420001/facultad
  * Node Name: `http://localhost:3001/alumnos/2420001/facultad ()({facultadClave})`
  * Method: `PUT`
  * Parameter: ``
  * Attack: ``
  * Evidence: `409`
  * Other Info: ``
* URL: http://localhost:3001/alumnos/2420001/facultad/
  * Node Name: `http://localhost:3001/alumnos/2420001/facultad/ ()({facultadClave})`
  * Method: `PUT`
  * Parameter: ``
  * Attack: ``
  * Evidence: `409`
  * Other Info: ``
* URL: http://localhost:3001/calificaciones/1.2/correccion
  * Node Name: `http://localhost:3001/calificaciones/1.2/correccion ()({valor,motivo,evidencia})`
  * Method: `PUT`
  * Parameter: ``
  * Attack: ``
  * Evidence: `400`
  * Other Info: ``
* URL: http://localhost:3001/calificaciones/1.2/correccion/
  * Node Name: `http://localhost:3001/calificaciones/1.2/correccion/ ()({valor,motivo,evidencia})`
  * Method: `PUT`
  * Parameter: ``
  * Attack: ``
  * Evidence: `400`
  * Other Info: ``
* URL: http://localhost:3001/grupos/1.2/calificaciones
  * Node Name: `http://localhost:3001/grupos/1.2/calificaciones ()({parcial,calificaciones:[{folio,valor}]})`
  * Method: `PUT`
  * Parameter: ``
  * Attack: ``
  * Evidence: `403`
  * Other Info: ``
* URL: http://localhost:3001/grupos/1.2/calificaciones/
  * Node Name: `http://localhost:3001/grupos/1.2/calificaciones/ ()({parcial,calificaciones:[{folio,valor}]})`
  * Method: `PUT`
  * Parameter: ``
  * Attack: ``
  * Evidence: `403`
  * Other Info: ``
* URL: http://localhost:3001/inscripciones/ISW-101/grupos
  * Node Name: `http://localhost:3001/inscripciones/ISW-101/grupos ()({grupos:[]})`
  * Method: `PUT`
  * Parameter: ``
  * Attack: ``
  * Evidence: `400`
  * Other Info: ``
* URL: http://localhost:3001/inscripciones/ISW-101/grupos
  * Node Name: `http://localhost:3001/inscripciones/ISW-101/grupos ()({grupos:[{}]})`
  * Method: `PUT`
  * Parameter: ``
  * Attack: ``
  * Evidence: `400`
  * Other Info: ``
* URL: http://localhost:3001/inscripciones/ISW-101/grupos/
  * Node Name: `http://localhost:3001/inscripciones/ISW-101/grupos/ ()({grupos:[{}]})`
  * Method: `PUT`
  * Parameter: ``
  * Attack: ``
  * Evidence: `400`
  * Other Info: ``


Instances: 164

### Solution



### Reference



#### CWE Id: [ 388 ](https://cwe.mitre.org/data/definitions/388.html)


#### WASC Id: 20

#### Source ID: 4

### [ Non-Storable Content ](https://www.zaproxy.org/docs/alerts/10049/)



##### Informational (Medium)

### Description

The response contents are not storable by caching components such as proxy servers. If the response does not contain sensitive, personal or user-specific information, it may benefit from being stored and cached, to improve performance.

* URL: http://localhost:3001/salud
  * Node Name: `http://localhost:3001/salud`
  * Method: `GET`
  * Parameter: ``
  * Attack: ``
  * Evidence: `no-store`
  * Other Info: ``
* URL: http://localhost:3001/sesiones/actual
  * Node Name: `http://localhost:3001/sesiones/actual`
  * Method: `GET`
  * Parameter: ``
  * Attack: ``
  * Evidence: `no-store`
  * Other Info: ``
* URL: http://localhost:3001/usuarios
  * Node Name: `http://localhost:3001/usuarios`
  * Method: `GET`
  * Parameter: ``
  * Attack: ``
  * Evidence: `no-store`
  * Other Info: ``
* URL: http://localhost:3001/sesiones
  * Node Name: `http://localhost:3001/sesiones ()({correo,contrasena})`
  * Method: `POST`
  * Parameter: ``
  * Attack: ``
  * Evidence: `no-store`
  * Other Info: ``
* URL: http://localhost:3001/sesiones/actual/renovacion
  * Node Name: `http://localhost:3001/sesiones/actual/renovacion`
  * Method: `POST`
  * Parameter: ``
  * Attack: ``
  * Evidence: `no-store`
  * Other Info: ``

Instances: Systemic


### Solution

The content may be marked as storable by ensuring that the following conditions are satisfied:
The request method must be understood by the cache and defined as being cacheable ("GET", "HEAD", and "POST" are currently defined as cacheable)
The response status code must be understood by the cache (one of the 1XX, 2XX, 3XX, 4XX, or 5XX response classes are generally understood)
The "no-store" cache directive must not appear in the request or response header fields
For caching by "shared" caches such as "proxy" caches, the "private" response directive must not appear in the response
For caching by "shared" caches such as "proxy" caches, the "Authorization" header field must not appear in the request, unless the response explicitly allows it (using one of the "must-revalidate", "public", or "s-maxage" Cache-Control response directives)
In addition to the conditions above, at least one of the following conditions must also be satisfied by the response:
It must contain an "Expires" header field
It must contain a "max-age" response directive
For "shared" caches such as "proxy" caches, it must contain a "s-maxage" response directive
It must contain a "Cache Control Extension" that allows it to be cached
It must have a status code that is defined as cacheable by default (200, 203, 204, 206, 300, 301, 404, 405, 410, 414, 501).

### Reference


* [ https://datatracker.ietf.org/doc/html/rfc7234 ](https://datatracker.ietf.org/doc/html/rfc7234)
* [ https://datatracker.ietf.org/doc/html/rfc7231 ](https://datatracker.ietf.org/doc/html/rfc7231)
* [ https://www.w3.org/Protocols/rfc2616/rfc2616-sec13.html ](https://www.w3.org/Protocols/rfc2616/rfc2616-sec13.html)


#### CWE Id: [ 524 ](https://cwe.mitre.org/data/definitions/524.html)


#### WASC Id: 13

#### Source ID: 3

### [ Session Management Response Identified ](https://www.zaproxy.org/docs/alerts/10112/)



##### Informational (Medium)

### Description

The given response has been identified as containing a session management token. The 'Other Info' field contains a set of header tokens that can be used in the Header Based Session Management Method. If the request is in a context which has a Session Management Method set to "Auto-Detect" then this rule will change the session management to use the tokens identified.

* URL: http://localhost:3001/sesiones/actual/renovacion
  * Node Name: `http://localhost:3001/sesiones/actual/renovacion`
  * Method: `POST`
  * Parameter: `token`
  * Attack: ``
  * Evidence: `token`
  * Other Info: `json:token`


Instances: 1

### Solution

This is an informational alert rather than a vulnerability and so there is nothing to fix.

### Reference


* [ https://www.zaproxy.org/docs/desktop/addons/authentication-helper/session-mgmt-id/ ](https://www.zaproxy.org/docs/desktop/addons/authentication-helper/session-mgmt-id/)



#### Source ID: 3


