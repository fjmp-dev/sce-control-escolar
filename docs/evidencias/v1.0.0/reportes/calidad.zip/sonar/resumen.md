### Puerta de calidad, Tabla 51: OK

| Indicador | Umbral | Medido |
|---|---|---|
| Cobertura en codigo nuevo | >= 80 % | sin dato |
| Errores bloqueantes | 0 | 0 |
| Errores criticos | 0 | 0 |
| Duplicidad en codigo nuevo | < 3 % | sin dato |
| Calificacion de seguridad (1 = A, 2 = B) | <= 2 | 1.0 |
| Deuda tecnica, en minutos (no rechaza: se documenta y se agenda) | < 480 | 0 |

Lineas nuevas: 0. Commit evaluado: 8e26059cefc3a921149d9f35aba2d86a352b39a5. Base: 53859403fbda64afa90d58920e0c04d0c6b5daff.
