# ZAP Scanning Report

ZAP by [Checkmarx](https://checkmarx.com/).


## Summary of Alerts

| Risk Level | Number of Alerts |
| --- | --- |
| High | 0 |
| Medium | 0 |
| Low | 0 |
| Informational | 3 |




## Insights

| Level | Reason | Site | Description | Statistic |
| --- | --- | --- | --- | --- |
| Medium | Exceeded High | http://localhost:3001 | Percentage of responses with status code 4xx | 88 % |
| Info | Informational | http://localhost:3001 | Percentage of responses with status code 2xx | 11 % |
| Info | Informational | http://localhost:3001 | Percentage of endpoints with content type application/json | 100 % |
| Info | Informational | http://localhost:3001 | Percentage of endpoints with method GET | 57 % |
| Info | Informational | http://localhost:3001 | Percentage of endpoints with method POST | 17 % |
| Info | Informational | http://localhost:3001 | Percentage of endpoints with method PUT | 25 % |
| Info | Informational | http://localhost:3001 | Count of total endpoints | 52    |







## Alerts

| Name | Risk Level | Number of Instances |
| --- | --- | --- |
| A Client Error response code was returned by the server | Informational | 46 |
| Non-Storable Content | Informational | Systemic |
| Session Management Response Identified | Informational | 1 |




## Alert Detail



### [ A Client Error response code was returned by the server ](https://www.zaproxy.org/docs/alerts/100000/)



##### Informational (High)

### Description

A response code of 400 was returned by the server.
This may indicate that the application is failing to handle unexpected input correctly.
Raised by the 'Alert on HTTP Response Code Error' script

* URL: http://localhost:3001
  * Node Name: `http://localhost:3001`
  * Method: `GET`
  * Parameter: ``
  * Attack: ``
  * Evidence: `404`
  * Other Info: ``
* URL: http://localhost:3001/
  * Node Name: `http://localhost:3001/`
  * Method: `GET`
  * Parameter: ``
  * Attack: ``
  * Evidence: `404`
  * Other Info: ``
* URL: http://localhost:3001/4124062925520271044
  * Node Name: `http://localhost:3001/4124062925520271044`
  * Method: `GET`
  * Parameter: ``
  * Attack: ``
  * Evidence: `404`
  * Other Info: ``
* URL: http://localhost:3001/alumnos%3F=
  * Node Name: `http://localhost:3001/alumnos`
  * Method: `GET`
  * Parameter: ``
  * Attack: ``
  * Evidence: `400`
  * Other Info: ``
* URL: http://localhost:3001/alumnos%3Fbuscar=%2523set%2528%2524engine%253D%2522%2522%2529%250A%2523set%2528%2524proc%253D%2524engine.getClass%2528%2529.forName%2528%2522java.lang.Runtime%2522%2529.getRuntime%2528%2529.exec%2528%2522sleep+15%2522%2529%2529%250A%2523set%2528%2524null%253D%2524proc.waitFor%2528%2529%2529%250A%2524%257Bnull%257D
  * Node Name: `http://localhost:3001/alumnos (buscar)`
  * Method: `GET`
  * Parameter: ``
  * Attack: ``
  * Evidence: `400`
  * Other Info: ``
* URL: http://localhost:3001/alumnos/2420001/2920758845108828094
  * Node Name: `http://localhost:3001/alumnos/2420001/2920758845108828094`
  * Method: `GET`
  * Parameter: ``
  * Attack: ``
  * Evidence: `404`
  * Other Info: ``
* URL: http://localhost:3001/alumnos/2420001/actuator/health
  * Node Name: `http://localhost:3001/alumnos/2420001/actuator/health`
  * Method: `GET`
  * Parameter: ``
  * Attack: ``
  * Evidence: `404`
  * Other Info: ``
* URL: http://localhost:3001/alumnos/8339164374371156350
  * Node Name: `http://localhost:3001/alumnos/8339164374371156350`
  * Method: `GET`
  * Parameter: ``
  * Attack: ``
  * Evidence: `400`
  * Other Info: ``
* URL: http://localhost:3001/documentos
  * Node Name: `http://localhost:3001/documentos`
  * Method: `GET`
  * Parameter: ``
  * Attack: ``
  * Evidence: `404`
  * Other Info: ``
* URL: http://localhost:3001/documentos/
  * Node Name: `http://localhost:3001/documentos/`
  * Method: `GET`
  * Parameter: ``
  * Attack: ``
  * Evidence: `404`
  * Other Info: ``
* URL: http://localhost:3001/documentos/532879272672285423
  * Node Name: `http://localhost:3001/documentos/532879272672285423`
  * Method: `GET`
  * Parameter: ``
  * Attack: ``
  * Evidence: `404`
  * Other Info: ``
* URL: http://localhost:3001/documentos/TRA-2420001-1A2B3C4D
  * Node Name: `http://localhost:3001/documentos/TRA-2420001-1A2B3C4D`
  * Method: `GET`
  * Parameter: ``
  * Attack: ``
  * Evidence: `404`
  * Other Info: ``
* URL: http://localhost:3001/documentos/TRA-2420001-1A2B3C4D/
  * Node Name: `http://localhost:3001/documentos/TRA-2420001-1A2B3C4D/`
  * Method: `GET`
  * Parameter: ``
  * Attack: ``
  * Evidence: `404`
  * Other Info: ``
* URL: http://localhost:3001/sesiones
  * Node Name: `http://localhost:3001/sesiones`
  * Method: `GET`
  * Parameter: ``
  * Attack: ``
  * Evidence: `404`
  * Other Info: ``
* URL: http://localhost:3001/sesiones/
  * Node Name: `http://localhost:3001/sesiones/`
  * Method: `GET`
  * Parameter: ``
  * Attack: ``
  * Evidence: `404`
  * Other Info: ``
* URL: http://localhost:3001/sesiones/278389803975877275
  * Node Name: `http://localhost:3001/sesiones/278389803975877275`
  * Method: `GET`
  * Parameter: ``
  * Attack: ``
  * Evidence: `404`
  * Other Info: ``
* URL: http://localhost:3001/sesiones/actual/7878932860960769429
  * Node Name: `http://localhost:3001/sesiones/actual/7878932860960769429`
  * Method: `GET`
  * Parameter: ``
  * Attack: ``
  * Evidence: `404`
  * Other Info: ``
* URL: http://localhost:3001/tramites%3F=
  * Node Name: `http://localhost:3001/tramites`
  * Method: `GET`
  * Parameter: ``
  * Attack: ``
  * Evidence: `400`
  * Other Info: ``
* URL: http://localhost:3001/tramites%3Festado=http%253A%252F%252Fwww.google.com%252F
  * Node Name: `http://localhost:3001/tramites (estado)`
  * Method: `GET`
  * Parameter: ``
  * Attack: ``
  * Evidence: `400`
  * Other Info: ``
* URL: http://localhost:3001/tramites/4023815543903952114
  * Node Name: `http://localhost:3001/tramites/4023815543903952114`
  * Method: `GET`
  * Parameter: ``
  * Attack: ``
  * Evidence: `404`
  * Other Info: ``
* URL: http://localhost:3001/tramites/TRA-2420001-1A2B3C4D
  * Node Name: `http://localhost:3001/tramites/TRA-2420001-1A2B3C4D`
  * Method: `GET`
  * Parameter: ``
  * Attack: ``
  * Evidence: `404`
  * Other Info: ``
* URL: http://localhost:3001/tramites/TRA-2420001-1A2B3C4D/
  * Node Name: `http://localhost:3001/tramites/TRA-2420001-1A2B3C4D/`
  * Method: `GET`
  * Parameter: ``
  * Attack: ``
  * Evidence: `404`
  * Other Info: ``
* URL: http://localhost:3001/tramites/TRA-2420001-1A2B3C4D/5029423164681232053
  * Node Name: `http://localhost:3001/tramites/TRA-2420001-1A2B3C4D/5029423164681232053`
  * Method: `GET`
  * Parameter: ``
  * Attack: ``
  * Evidence: `404`
  * Other Info: ``
* URL: http://localhost:3001/alumnos
  * Node Name: `http://localhost:3001/alumnos ()({matricula,nombre,facultadClave,fechaIngreso,correo})`
  * Method: `POST`
  * Parameter: ``
  * Attack: ``
  * Evidence: `400`
  * Other Info: ``
* URL: http://localhost:3001/alumnos/
  * Node Name: `http://localhost:3001/alumnos/ ()({matricula,nombre,facultadClave,fechaIngreso,correo})`
  * Method: `POST`
  * Parameter: ``
  * Attack: ``
  * Evidence: `400`
  * Other Info: ``
* URL: http://localhost:3001/tramites/TRA-2420001-1A2B3C4D/emision
  * Node Name: `http://localhost:3001/tramites/TRA-2420001-1A2B3C4D/emision`
  * Method: `POST`
  * Parameter: ``
  * Attack: ``
  * Evidence: `404`
  * Other Info: ``
* URL: http://localhost:3001/tramites/TRA-2420001-1A2B3C4D/emision/
  * Node Name: `http://localhost:3001/tramites/TRA-2420001-1A2B3C4D/emision/`
  * Method: `POST`
  * Parameter: ``
  * Attack: ``
  * Evidence: `404`
  * Other Info: ``
* URL: http://localhost:3001/tramites/TRA-2420001-1A2B3C4D/proceso
  * Node Name: `http://localhost:3001/tramites/TRA-2420001-1A2B3C4D/proceso`
  * Method: `POST`
  * Parameter: ``
  * Attack: ``
  * Evidence: `404`
  * Other Info: ``
* URL: http://localhost:3001/tramites/TRA-2420001-1A2B3C4D/proceso/
  * Node Name: `http://localhost:3001/tramites/TRA-2420001-1A2B3C4D/proceso/`
  * Method: `POST`
  * Parameter: ``
  * Attack: ``
  * Evidence: `404`
  * Other Info: ``
* URL: http://localhost:3001/tramites/TRA-2420001-1A2B3C4D/rechazo
  * Node Name: `http://localhost:3001/tramites/TRA-2420001-1A2B3C4D/rechazo ()({motivo})`
  * Method: `POST`
  * Parameter: ``
  * Attack: ``
  * Evidence: `400`
  * Other Info: ``
* URL: http://localhost:3001/tramites/TRA-2420001-1A2B3C4D/rechazo
  * Node Name: `http://localhost:3001/tramites/TRA-2420001-1A2B3C4D/rechazo ()({motivo})`
  * Method: `POST`
  * Parameter: ``
  * Attack: ``
  * Evidence: `404`
  * Other Info: ``
* URL: http://localhost:3001/tramites/TRA-2420001-1A2B3C4D/rechazo/
  * Node Name: `http://localhost:3001/tramites/TRA-2420001-1A2B3C4D/rechazo/ ()({motivo})`
  * Method: `POST`
  * Parameter: ``
  * Attack: ``
  * Evidence: `404`
  * Other Info: ``
* URL: http://localhost:3001/alumnos/2420001/cuenta
  * Node Name: `http://localhost:3001/alumnos/2420001/cuenta ()({correo})`
  * Method: `PUT`
  * Parameter: ``
  * Attack: ``
  * Evidence: `400`
  * Other Info: ``
* URL: http://localhost:3001/alumnos/2420001/cuenta/
  * Node Name: `http://localhost:3001/alumnos/2420001/cuenta/ ()({correo})`
  * Method: `PUT`
  * Parameter: ``
  * Attack: ``
  * Evidence: `400`
  * Other Info: ``
* URL: http://localhost:3001/alumnos/2420001/estatus
  * Node Name: `http://localhost:3001/alumnos/2420001/estatus ()({estatus})`
  * Method: `PUT`
  * Parameter: ``
  * Attack: ``
  * Evidence: `400`
  * Other Info: ``
* URL: http://localhost:3001/alumnos/2420001/estatus
  * Node Name: `http://localhost:3001/alumnos/2420001/estatus ()({estatus})`
  * Method: `PUT`
  * Parameter: ``
  * Attack: ``
  * Evidence: `409`
  * Other Info: ``
* URL: http://localhost:3001/alumnos/2420001/estatus/
  * Node Name: `http://localhost:3001/alumnos/2420001/estatus/ ()({estatus})`
  * Method: `PUT`
  * Parameter: ``
  * Attack: ``
  * Evidence: `409`
  * Other Info: ``
* URL: http://localhost:3001/alumnos/2420001/facultad
  * Node Name: `http://localhost:3001/alumnos/2420001/facultad ()({facultadClave})`
  * Method: `PUT`
  * Parameter: ``
  * Attack: ``
  * Evidence: `400`
  * Other Info: ``
* URL: http://localhost:3001/alumnos/2420001/facultad/
  * Node Name: `http://localhost:3001/alumnos/2420001/facultad/ ()({facultadClave})`
  * Method: `PUT`
  * Parameter: ``
  * Attack: ``
  * Evidence: `400`
  * Other Info: ``
* URL: http://localhost:3001/computeMetadata/v1/
  * Node Name: `http://localhost:3001/computeMetadata/v1/ ()({correo})`
  * Method: `PUT`
  * Parameter: ``
  * Attack: ``
  * Evidence: `404`
  * Other Info: ``
* URL: http://localhost:3001/latest/meta-data/
  * Node Name: `http://localhost:3001/latest/meta-data/ ()({correo})`
  * Method: `PUT`
  * Parameter: ``
  * Attack: ``
  * Evidence: `404`
  * Other Info: ``
* URL: http://localhost:3001/metadata/instance
  * Node Name: `http://localhost:3001/metadata/instance ()({correo})`
  * Method: `PUT`
  * Parameter: ``
  * Attack: ``
  * Evidence: `404`
  * Other Info: ``
* URL: http://localhost:3001/metadata/v1
  * Node Name: `http://localhost:3001/metadata/v1 ()({correo})`
  * Method: `PUT`
  * Parameter: ``
  * Attack: ``
  * Evidence: `404`
  * Other Info: ``
* URL: http://localhost:3001/opc/v1/instance/
  * Node Name: `http://localhost:3001/opc/v1/instance/ ()({correo})`
  * Method: `PUT`
  * Parameter: ``
  * Attack: ``
  * Evidence: `404`
  * Other Info: ``
* URL: http://localhost:3001/opc/v2/instance/
  * Node Name: `http://localhost:3001/opc/v2/instance/ ()({correo})`
  * Method: `PUT`
  * Parameter: ``
  * Attack: ``
  * Evidence: `404`
  * Other Info: ``
* URL: http://localhost:3001/openstack/latest/meta_data.json
  * Node Name: `http://localhost:3001/openstack/latest/meta_data.json ()({correo})`
  * Method: `PUT`
  * Parameter: ``
  * Attack: ``
  * Evidence: `404`
  * Other Info: ``


Instances: 46

### Solution



### Reference



#### CWE Id: [ 388 ](https://cwe.mitre.org/data/definitions/388.html)


#### WASC Id: 20

#### Source ID: 4

### [ Non-Storable Content ](https://www.zaproxy.org/docs/alerts/10049/)



##### Informational (Medium)

### Description

The response contents are not storable by caching components such as proxy servers. If the response does not contain sensitive, personal or user-specific information, it may benefit from being stored and cached, to improve performance.

* URL: http://localhost:3001/facultades
  * Node Name: `http://localhost:3001/facultades`
  * Method: `GET`
  * Parameter: ``
  * Attack: ``
  * Evidence: `no-store`
  * Other Info: ``
* URL: http://localhost:3001/materias
  * Node Name: `http://localhost:3001/materias`
  * Method: `GET`
  * Parameter: ``
  * Attack: ``
  * Evidence: `no-store`
  * Other Info: ``
* URL: http://localhost:3001/planes
  * Node Name: `http://localhost:3001/planes`
  * Method: `GET`
  * Parameter: ``
  * Attack: ``
  * Evidence: `no-store`
  * Other Info: ``
* URL: http://localhost:3001/sesiones/actual
  * Node Name: `http://localhost:3001/sesiones/actual`
  * Method: `GET`
  * Parameter: ``
  * Attack: ``
  * Evidence: `no-store`
  * Other Info: ``
* URL: http://localhost:3001/sesiones/actual/renovacion
  * Node Name: `http://localhost:3001/sesiones/actual/renovacion`
  * Method: `POST`
  * Parameter: ``
  * Attack: ``
  * Evidence: `no-store`
  * Other Info: ``

Instances: Systemic


### Solution

The content may be marked as storable by ensuring that the following conditions are satisfied:
The request method must be understood by the cache and defined as being cacheable ("GET", "HEAD", and "POST" are currently defined as cacheable)
The response status code must be understood by the cache (one of the 1XX, 2XX, 3XX, 4XX, or 5XX response classes are generally understood)
The "no-store" cache directive must not appear in the request or response header fields
For caching by "shared" caches such as "proxy" caches, the "private" response directive must not appear in the response
For caching by "shared" caches such as "proxy" caches, the "Authorization" header field must not appear in the request, unless the response explicitly allows it (using one of the "must-revalidate", "public", or "s-maxage" Cache-Control response directives)
In addition to the conditions above, at least one of the following conditions must also be satisfied by the response:
It must contain an "Expires" header field
It must contain a "max-age" response directive
For "shared" caches such as "proxy" caches, it must contain a "s-maxage" response directive
It must contain a "Cache Control Extension" that allows it to be cached
It must have a status code that is defined as cacheable by default (200, 203, 204, 206, 300, 301, 404, 405, 410, 414, 501).

### Reference


* [ https://datatracker.ietf.org/doc/html/rfc7234 ](https://datatracker.ietf.org/doc/html/rfc7234)
* [ https://datatracker.ietf.org/doc/html/rfc7231 ](https://datatracker.ietf.org/doc/html/rfc7231)
* [ https://www.w3.org/Protocols/rfc2616/rfc2616-sec13.html ](https://www.w3.org/Protocols/rfc2616/rfc2616-sec13.html)


#### CWE Id: [ 524 ](https://cwe.mitre.org/data/definitions/524.html)


#### WASC Id: 13

#### Source ID: 3

### [ Session Management Response Identified ](https://www.zaproxy.org/docs/alerts/10112/)



##### Informational (Medium)

### Description

The given response has been identified as containing a session management token. The 'Other Info' field contains a set of header tokens that can be used in the Header Based Session Management Method. If the request is in a context which has a Session Management Method set to "Auto-Detect" then this rule will change the session management to use the tokens identified.

* URL: http://localhost:3001/sesiones/actual/renovacion
  * Node Name: `http://localhost:3001/sesiones/actual/renovacion`
  * Method: `POST`
  * Parameter: `token`
  * Attack: ``
  * Evidence: `token`
  * Other Info: `json:token`


Instances: 1

### Solution

This is an informational alert rather than a vulnerability and so there is nothing to fix.

### Reference


* [ https://www.zaproxy.org/docs/desktop/addons/authentication-helper/session-mgmt-id/ ](https://www.zaproxy.org/docs/desktop/addons/authentication-helper/session-mgmt-id/)



#### Source ID: 3


