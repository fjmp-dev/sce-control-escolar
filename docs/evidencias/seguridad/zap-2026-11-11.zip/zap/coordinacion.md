# ZAP Scanning Report

ZAP by [Checkmarx](https://checkmarx.com/).


## Summary of Alerts

| Risk Level | Number of Alerts |
| --- | --- |
| High | 0 |
| Medium | 0 |
| Low | 0 |
| Informational | 3 |




## Insights

| Level | Reason | Site | Description | Statistic |
| --- | --- | --- | --- | --- |
| Medium | Exceeded High | http://localhost:3221 | Percentage of responses with status code 4xx | 99 % |
| Info | Informational | http://localhost:3221 | Percentage of endpoints with content type application/json | 100 % |
| Info | Informational | http://localhost:3221 | Percentage of endpoints with method DELETE | 3 % |
| Info | Informational | http://localhost:3221 | Percentage of endpoints with method GET | 58 % |
| Info | Informational | http://localhost:3221 | Percentage of endpoints with method POST | 23 % |
| Info | Informational | http://localhost:3221 | Percentage of endpoints with method PUT | 14 % |
| Info | Informational | http://localhost:3221 | Count of total endpoints | 63    |







## Alerts

| Name | Risk Level | Number of Instances |
| --- | --- | --- |
| A Client Error response code was returned by the server | Informational | 57 |
| Non-Storable Content | Informational | Systemic |
| Session Management Response Identified | Informational | 1 |




## Alert Detail



### [ A Client Error response code was returned by the server ](https://www.zaproxy.org/docs/alerts/100000/)



##### Informational (High)

### Description

A response code of 400 was returned by the server.
This may indicate that the application is failing to handle unexpected input correctly.
Raised by the 'Alert on HTTP Response Code Error' script

* URL: http://localhost:3221/materias/ISW-101/prerrequisitos/ISW-101
  * Node Name: `http://localhost:3221/materias/ISW-101/prerrequisitos/ISW-101`
  * Method: `DELETE`
  * Parameter: ``
  * Attack: ``
  * Evidence: `404`
  * Other Info: ``
* URL: http://localhost:3221/materias/ISW-101/prerrequisitos/ISW-101/
  * Node Name: `http://localhost:3221/materias/ISW-101/prerrequisitos/ISW-101/`
  * Method: `DELETE`
  * Parameter: ``
  * Attack: ``
  * Evidence: `404`
  * Other Info: ``
* URL: http://localhost:3221
  * Node Name: `http://localhost:3221`
  * Method: `GET`
  * Parameter: ``
  * Attack: ``
  * Evidence: `404`
  * Other Info: ``
* URL: http://localhost:3221/
  * Node Name: `http://localhost:3221/`
  * Method: `GET`
  * Parameter: ``
  * Attack: ``
  * Evidence: `404`
  * Other Info: ``
* URL: http://localhost:3221/7575346339614820223
  * Node Name: `http://localhost:3221/7575346339614820223`
  * Method: `GET`
  * Parameter: ``
  * Attack: ``
  * Evidence: `404`
  * Other Info: ``
* URL: http://localhost:3221/alumnos
  * Node Name: `http://localhost:3221/alumnos`
  * Method: `GET`
  * Parameter: ``
  * Attack: ``
  * Evidence: `403`
  * Other Info: ``
* URL: http://localhost:3221/alumnos/
  * Node Name: `http://localhost:3221/alumnos/`
  * Method: `GET`
  * Parameter: ``
  * Attack: ``
  * Evidence: `403`
  * Other Info: ``
* URL: http://localhost:3221/alumnos/2420001
  * Node Name: `http://localhost:3221/alumnos/2420001`
  * Method: `GET`
  * Parameter: ``
  * Attack: ``
  * Evidence: `403`
  * Other Info: ``
* URL: http://localhost:3221/alumnos/2420001/
  * Node Name: `http://localhost:3221/alumnos/2420001/`
  * Method: `GET`
  * Parameter: ``
  * Attack: ``
  * Evidence: `403`
  * Other Info: ``
* URL: http://localhost:3221/alumnos/2420001/337229522142700090
  * Node Name: `http://localhost:3221/alumnos/2420001/337229522142700090`
  * Method: `GET`
  * Parameter: ``
  * Attack: ``
  * Evidence: `404`
  * Other Info: ``
* URL: http://localhost:3221/alumnos/7426020656170018927
  * Node Name: `http://localhost:3221/alumnos/7426020656170018927`
  * Method: `GET`
  * Parameter: ``
  * Attack: ``
  * Evidence: `403`
  * Other Info: ``
* URL: http://localhost:3221/calificaciones
  * Node Name: `http://localhost:3221/calificaciones`
  * Method: `GET`
  * Parameter: ``
  * Attack: ``
  * Evidence: `404`
  * Other Info: ``
* URL: http://localhost:3221/calificaciones/
  * Node Name: `http://localhost:3221/calificaciones/`
  * Method: `GET`
  * Parameter: ``
  * Attack: ``
  * Evidence: `404`
  * Other Info: ``
* URL: http://localhost:3221/calificaciones/1.2
  * Node Name: `http://localhost:3221/calificaciones/1.2`
  * Method: `GET`
  * Parameter: ``
  * Attack: ``
  * Evidence: `404`
  * Other Info: ``
* URL: http://localhost:3221/calificaciones/1.2/
  * Node Name: `http://localhost:3221/calificaciones/1.2/`
  * Method: `GET`
  * Parameter: ``
  * Attack: ``
  * Evidence: `404`
  * Other Info: ``
* URL: http://localhost:3221/calificaciones/1.2/5514647010162611046
  * Node Name: `http://localhost:3221/calificaciones/1.2/5514647010162611046`
  * Method: `GET`
  * Parameter: ``
  * Attack: ``
  * Evidence: `404`
  * Other Info: ``
* URL: http://localhost:3221/calificaciones/1.2/actuator/health
  * Node Name: `http://localhost:3221/calificaciones/1.2/actuator/health`
  * Method: `GET`
  * Parameter: ``
  * Attack: ``
  * Evidence: `404`
  * Other Info: ``
* URL: http://localhost:3221/calificaciones/3204578942279351895
  * Node Name: `http://localhost:3221/calificaciones/3204578942279351895`
  * Method: `GET`
  * Parameter: ``
  * Attack: ``
  * Evidence: `404`
  * Other Info: ``
* URL: http://localhost:3221/materias/1854922171239964125
  * Node Name: `http://localhost:3221/materias/1854922171239964125`
  * Method: `GET`
  * Parameter: ``
  * Attack: ``
  * Evidence: `404`
  * Other Info: ``
* URL: http://localhost:3221/materias/ISW-101
  * Node Name: `http://localhost:3221/materias/ISW-101`
  * Method: `GET`
  * Parameter: ``
  * Attack: ``
  * Evidence: `404`
  * Other Info: ``
* URL: http://localhost:3221/materias/ISW-101/
  * Node Name: `http://localhost:3221/materias/ISW-101/`
  * Method: `GET`
  * Parameter: ``
  * Attack: ``
  * Evidence: `404`
  * Other Info: ``
* URL: http://localhost:3221/materias/ISW-101/9106248302467609335
  * Node Name: `http://localhost:3221/materias/ISW-101/9106248302467609335`
  * Method: `GET`
  * Parameter: ``
  * Attack: ``
  * Evidence: `404`
  * Other Info: ``
* URL: http://localhost:3221/materias/ISW-101/prerrequisitos
  * Node Name: `http://localhost:3221/materias/ISW-101/prerrequisitos`
  * Method: `GET`
  * Parameter: ``
  * Attack: ``
  * Evidence: `404`
  * Other Info: ``
* URL: http://localhost:3221/materias/ISW-101/prerrequisitos/
  * Node Name: `http://localhost:3221/materias/ISW-101/prerrequisitos/`
  * Method: `GET`
  * Parameter: ``
  * Attack: ``
  * Evidence: `404`
  * Other Info: ``
* URL: http://localhost:3221/materias/ISW-101/prerrequisitos/4303244655144777153
  * Node Name: `http://localhost:3221/materias/ISW-101/prerrequisitos/4303244655144777153`
  * Method: `GET`
  * Parameter: ``
  * Attack: ``
  * Evidence: `404`
  * Other Info: ``
* URL: http://localhost:3221/periodos/2027A
  * Node Name: `http://localhost:3221/periodos/2027A`
  * Method: `GET`
  * Parameter: ``
  * Attack: ``
  * Evidence: `404`
  * Other Info: ``
* URL: http://localhost:3221/periodos/2027A/
  * Node Name: `http://localhost:3221/periodos/2027A/`
  * Method: `GET`
  * Parameter: ``
  * Attack: ``
  * Evidence: `404`
  * Other Info: ``
* URL: http://localhost:3221/periodos/2027A/4337377123724424393
  * Node Name: `http://localhost:3221/periodos/2027A/4337377123724424393`
  * Method: `GET`
  * Parameter: ``
  * Attack: ``
  * Evidence: `404`
  * Other Info: ``
* URL: http://localhost:3221/periodos/4966368068281491401
  * Node Name: `http://localhost:3221/periodos/4966368068281491401`
  * Method: `GET`
  * Parameter: ``
  * Attack: ``
  * Evidence: `404`
  * Other Info: ``
* URL: http://localhost:3221/sesiones
  * Node Name: `http://localhost:3221/sesiones`
  * Method: `GET`
  * Parameter: ``
  * Attack: ``
  * Evidence: `404`
  * Other Info: ``
* URL: http://localhost:3221/sesiones/
  * Node Name: `http://localhost:3221/sesiones/`
  * Method: `GET`
  * Parameter: ``
  * Attack: ``
  * Evidence: `404`
  * Other Info: ``
* URL: http://localhost:3221/sesiones/4189596036842057314
  * Node Name: `http://localhost:3221/sesiones/4189596036842057314`
  * Method: `GET`
  * Parameter: ``
  * Attack: ``
  * Evidence: `404`
  * Other Info: ``
* URL: http://localhost:3221/sesiones/actual/6480318171357421381
  * Node Name: `http://localhost:3221/sesiones/actual/6480318171357421381`
  * Method: `GET`
  * Parameter: ``
  * Attack: ``
  * Evidence: `404`
  * Other Info: ``
* URL: http://localhost:3221/grupos
  * Node Name: `http://localhost:3221/grupos ()({periodoClave,clave,materiaClave,profesor,cupo,horarios:[{dia,horaInicio,horaFin,aula}]})`
  * Method: `POST`
  * Parameter: ``
  * Attack: ``
  * Evidence: `400`
  * Other Info: ``
* URL: http://localhost:3221/grupos/
  * Node Name: `http://localhost:3221/grupos/ ()({periodoClave,clave,materiaClave,profesor,cupo,horarios:[{dia,horaInicio,horaFin,aula}]})`
  * Method: `POST`
  * Parameter: ``
  * Attack: ``
  * Evidence: `400`
  * Other Info: ``
* URL: http://localhost:3221/materias
  * Node Name: `http://localhost:3221/materias ()({clave,planClave,nombre,creditos})`
  * Method: `POST`
  * Parameter: ``
  * Attack: ``
  * Evidence: `400`
  * Other Info: ``
* URL: http://localhost:3221/materias/
  * Node Name: `http://localhost:3221/materias/ ()({clave,planClave,nombre,creditos})`
  * Method: `POST`
  * Parameter: ``
  * Attack: ``
  * Evidence: `400`
  * Other Info: ``
* URL: http://localhost:3221/materias/ISW-101/prerrequisitos
  * Node Name: `http://localhost:3221/materias/ISW-101/prerrequisitos ()({requiereClave,obligatorio})`
  * Method: `POST`
  * Parameter: ``
  * Attack: ``
  * Evidence: `400`
  * Other Info: ``
* URL: http://localhost:3221/materias/ISW-101/prerrequisitos
  * Node Name: `http://localhost:3221/materias/ISW-101/prerrequisitos ()({requiereClave,obligatorio})`
  * Method: `POST`
  * Parameter: ``
  * Attack: ``
  * Evidence: `409`
  * Other Info: ``
* URL: http://localhost:3221/materias/ISW-101/prerrequisitos/
  * Node Name: `http://localhost:3221/materias/ISW-101/prerrequisitos/ ()({requiereClave,obligatorio})`
  * Method: `POST`
  * Parameter: ``
  * Attack: ``
  * Evidence: `409`
  * Other Info: ``
* URL: http://localhost:3221/periodos
  * Node Name: `http://localhost:3221/periodos ()({clave,fechaInicio,fechaFin})`
  * Method: `POST`
  * Parameter: ``
  * Attack: ``
  * Evidence: `400`
  * Other Info: ``
* URL: http://localhost:3221/periodos
  * Node Name: `http://localhost:3221/periodos ()({clave,fechaInicio,fechaFin})`
  * Method: `POST`
  * Parameter: ``
  * Attack: ``
  * Evidence: `409`
  * Other Info: ``
* URL: http://localhost:3221/periodos/
  * Node Name: `http://localhost:3221/periodos/ ()({clave,fechaInicio,fechaFin})`
  * Method: `POST`
  * Parameter: ``
  * Attack: ``
  * Evidence: `400`
  * Other Info: ``
* URL: http://localhost:3221/periodos/2027A/cierre
  * Node Name: `http://localhost:3221/periodos/2027A/cierre`
  * Method: `POST`
  * Parameter: ``
  * Attack: ``
  * Evidence: `409`
  * Other Info: ``
* URL: http://localhost:3221/periodos/2027A/cierre/
  * Node Name: `http://localhost:3221/periodos/2027A/cierre/`
  * Method: `POST`
  * Parameter: ``
  * Attack: ``
  * Evidence: `409`
  * Other Info: ``
* URL: http://localhost:3221/periodos/2027A/inicio/
  * Node Name: `http://localhost:3221/periodos/2027A/inicio/`
  * Method: `POST`
  * Parameter: ``
  * Attack: ``
  * Evidence: `409`
  * Other Info: ``
* URL: http://localhost:3221/periodos/2027A/publicacion
  * Node Name: `http://localhost:3221/periodos/2027A/publicacion`
  * Method: `POST`
  * Parameter: ``
  * Attack: ``
  * Evidence: `409`
  * Other Info: ``
* URL: http://localhost:3221/periodos/2027A/publicacion/
  * Node Name: `http://localhost:3221/periodos/2027A/publicacion/`
  * Method: `POST`
  * Parameter: ``
  * Attack: ``
  * Evidence: `409`
  * Other Info: ``
* URL: http://localhost:3221/calificaciones/1.2/correccion
  * Node Name: `http://localhost:3221/calificaciones/1.2/correccion ()({valor,motivo,evidencia})`
  * Method: `PUT`
  * Parameter: ``
  * Attack: ``
  * Evidence: `400`
  * Other Info: ``
* URL: http://localhost:3221/calificaciones/1.2/correccion/
  * Node Name: `http://localhost:3221/calificaciones/1.2/correccion/ ()({valor,motivo,evidencia})`
  * Method: `PUT`
  * Parameter: ``
  * Attack: ``
  * Evidence: `400`
  * Other Info: ``
* URL: http://localhost:3221/computeMetadata/v1/
  * Node Name: `http://localhost:3221/computeMetadata/v1/ ()({valor,motivo,evidencia})`
  * Method: `PUT`
  * Parameter: ``
  * Attack: ``
  * Evidence: `404`
  * Other Info: ``
* URL: http://localhost:3221/latest/meta-data/
  * Node Name: `http://localhost:3221/latest/meta-data/ ()({valor,motivo,evidencia})`
  * Method: `PUT`
  * Parameter: ``
  * Attack: ``
  * Evidence: `404`
  * Other Info: ``
* URL: http://localhost:3221/metadata/instance
  * Node Name: `http://localhost:3221/metadata/instance ()({valor,motivo,evidencia})`
  * Method: `PUT`
  * Parameter: ``
  * Attack: ``
  * Evidence: `404`
  * Other Info: ``
* URL: http://localhost:3221/metadata/v1
  * Node Name: `http://localhost:3221/metadata/v1 ()({valor,motivo,evidencia})`
  * Method: `PUT`
  * Parameter: ``
  * Attack: ``
  * Evidence: `404`
  * Other Info: ``
* URL: http://localhost:3221/opc/v1/instance/
  * Node Name: `http://localhost:3221/opc/v1/instance/ ()({valor,motivo,evidencia})`
  * Method: `PUT`
  * Parameter: ``
  * Attack: ``
  * Evidence: `404`
  * Other Info: ``
* URL: http://localhost:3221/opc/v2/instance/
  * Node Name: `http://localhost:3221/opc/v2/instance/ ()({valor,motivo,evidencia})`
  * Method: `PUT`
  * Parameter: ``
  * Attack: ``
  * Evidence: `404`
  * Other Info: ``
* URL: http://localhost:3221/openstack/latest/meta_data.json
  * Node Name: `http://localhost:3221/openstack/latest/meta_data.json ()({valor,motivo,evidencia})`
  * Method: `PUT`
  * Parameter: ``
  * Attack: ``
  * Evidence: `404`
  * Other Info: ``


Instances: 57

### Solution



### Reference



#### CWE Id: [ 388 ](https://cwe.mitre.org/data/definitions/388.html)


#### WASC Id: 20

#### Source ID: 4

### [ Non-Storable Content ](https://www.zaproxy.org/docs/alerts/10049/)



##### Informational (Medium)

### Description

The response contents are not storable by caching components such as proxy servers. If the response does not contain sensitive, personal or user-specific information, it may benefit from being stored and cached, to improve performance.

* URL: http://localhost:3221/facultades
  * Node Name: `http://localhost:3221/facultades`
  * Method: `GET`
  * Parameter: ``
  * Attack: ``
  * Evidence: `no-store`
  * Other Info: ``
* URL: http://localhost:3221/planes
  * Node Name: `http://localhost:3221/planes`
  * Method: `GET`
  * Parameter: ``
  * Attack: ``
  * Evidence: `no-store`
  * Other Info: ``
* URL: http://localhost:3221/sesiones/actual
  * Node Name: `http://localhost:3221/sesiones/actual`
  * Method: `GET`
  * Parameter: ``
  * Attack: ``
  * Evidence: `no-store`
  * Other Info: ``
* URL: http://localhost:3221/materias
  * Node Name: `http://localhost:3221/materias ()({clave,planClave,nombre,creditos})`
  * Method: `POST`
  * Parameter: ``
  * Attack: ``
  * Evidence: `no-store`
  * Other Info: ``
* URL: http://localhost:3221/sesiones/actual/renovacion
  * Node Name: `http://localhost:3221/sesiones/actual/renovacion`
  * Method: `POST`
  * Parameter: ``
  * Attack: ``
  * Evidence: `no-store`
  * Other Info: ``

Instances: Systemic


### Solution

The content may be marked as storable by ensuring that the following conditions are satisfied:
The request method must be understood by the cache and defined as being cacheable ("GET", "HEAD", and "POST" are currently defined as cacheable)
The response status code must be understood by the cache (one of the 1XX, 2XX, 3XX, 4XX, or 5XX response classes are generally understood)
The "no-store" cache directive must not appear in the request or response header fields
For caching by "shared" caches such as "proxy" caches, the "private" response directive must not appear in the response
For caching by "shared" caches such as "proxy" caches, the "Authorization" header field must not appear in the request, unless the response explicitly allows it (using one of the "must-revalidate", "public", or "s-maxage" Cache-Control response directives)
In addition to the conditions above, at least one of the following conditions must also be satisfied by the response:
It must contain an "Expires" header field
It must contain a "max-age" response directive
For "shared" caches such as "proxy" caches, it must contain a "s-maxage" response directive
It must contain a "Cache Control Extension" that allows it to be cached
It must have a status code that is defined as cacheable by default (200, 203, 204, 206, 300, 301, 404, 405, 410, 414, 501).

### Reference


* [ https://datatracker.ietf.org/doc/html/rfc7234 ](https://datatracker.ietf.org/doc/html/rfc7234)
* [ https://datatracker.ietf.org/doc/html/rfc7231 ](https://datatracker.ietf.org/doc/html/rfc7231)
* [ https://www.w3.org/Protocols/rfc2616/rfc2616-sec13.html ](https://www.w3.org/Protocols/rfc2616/rfc2616-sec13.html)


#### CWE Id: [ 524 ](https://cwe.mitre.org/data/definitions/524.html)


#### WASC Id: 13

#### Source ID: 3

### [ Session Management Response Identified ](https://www.zaproxy.org/docs/alerts/10112/)



##### Informational (Medium)

### Description

The given response has been identified as containing a session management token. The 'Other Info' field contains a set of header tokens that can be used in the Header Based Session Management Method. If the request is in a context which has a Session Management Method set to "Auto-Detect" then this rule will change the session management to use the tokens identified.

* URL: http://localhost:3221/sesiones/actual/renovacion
  * Node Name: `http://localhost:3221/sesiones/actual/renovacion`
  * Method: `POST`
  * Parameter: `token`
  * Attack: ``
  * Evidence: `token`
  * Other Info: `json:token`


Instances: 1

### Solution

This is an informational alert rather than a vulnerability and so there is nothing to fix.

### Reference


* [ https://www.zaproxy.org/docs/desktop/addons/authentication-helper/session-mgmt-id/ ](https://www.zaproxy.org/docs/desktop/addons/authentication-helper/session-mgmt-id/)



#### Source ID: 3


