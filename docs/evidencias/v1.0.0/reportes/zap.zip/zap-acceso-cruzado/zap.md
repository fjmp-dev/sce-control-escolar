# ZAP Scanning Report

ZAP by [Checkmarx](https://checkmarx.com/).


## Summary of Alerts

| Risk Level | Number of Alerts |
| --- | --- |
| High | 0 |
| Medium | 0 |
| Low | 0 |
| Informational | 2 |




## Insights

| Level | Reason | Site | Description | Statistic |
| --- | --- | --- | --- | --- |
| Medium | Exceeded High | http://localhost:3001 | Percentage of responses with status code 4xx | 100 % |
| Info | Informational | http://localhost:3001 | Percentage of endpoints with content type application/json | 100 % |
| Info | Informational | http://localhost:3001 | Percentage of endpoints with method GET | 61 % |
| Info | Informational | http://localhost:3001 | Percentage of endpoints with method PATCH | 2 % |
| Info | Informational | http://localhost:3001 | Percentage of endpoints with method POST | 23 % |
| Info | Informational | http://localhost:3001 | Percentage of endpoints with method PUT | 12 % |
| Info | Informational | http://localhost:3001 | Count of total endpoints | 73    |







## Alerts

| Name | Risk Level | Number of Instances |
| --- | --- | --- |
| A Client Error response code was returned by the server | Informational | 75 |
| Non-Storable Content | Informational | Systemic |




## Alert Detail



### [ A Client Error response code was returned by the server ](https://www.zaproxy.org/docs/alerts/100000/)



##### Informational (High)

### Description

A response code of 403 was returned by the server.
This may indicate that the application is failing to handle unexpected input correctly.
Raised by the 'Alert on HTTP Response Code Error' script

* URL: http://localhost:3001
  * Node Name: `http://localhost:3001`
  * Method: `GET`
  * Parameter: ``
  * Attack: ``
  * Evidence: `404`
  * Other Info: ``
* URL: http://localhost:3001/
  * Node Name: `http://localhost:3001/`
  * Method: `GET`
  * Parameter: ``
  * Attack: ``
  * Evidence: `404`
  * Other Info: ``
* URL: http://localhost:3001/2591503740139563775
  * Node Name: `http://localhost:3001/2591503740139563775`
  * Method: `GET`
  * Parameter: ``
  * Attack: ``
  * Evidence: `404`
  * Other Info: ``
* URL: http://localhost:3001/alumnos
  * Node Name: `http://localhost:3001/alumnos`
  * Method: `GET`
  * Parameter: ``
  * Attack: ``
  * Evidence: `403`
  * Other Info: ``
* URL: http://localhost:3001/alumnos/
  * Node Name: `http://localhost:3001/alumnos/`
  * Method: `GET`
  * Parameter: ``
  * Attack: ``
  * Evidence: `403`
  * Other Info: ``
* URL: http://localhost:3001/alumnos/2420002
  * Node Name: `http://localhost:3001/alumnos/2420002`
  * Method: `GET`
  * Parameter: ``
  * Attack: ``
  * Evidence: `403`
  * Other Info: ``
* URL: http://localhost:3001/alumnos/2420002/
  * Node Name: `http://localhost:3001/alumnos/2420002/`
  * Method: `GET`
  * Parameter: ``
  * Attack: ``
  * Evidence: `403`
  * Other Info: ``
* URL: http://localhost:3001/alumnos/2420002/6149749224144248391
  * Node Name: `http://localhost:3001/alumnos/2420002/6149749224144248391`
  * Method: `GET`
  * Parameter: ``
  * Attack: ``
  * Evidence: `404`
  * Other Info: ``
* URL: http://localhost:3001/alumnos/2420002/actuator/health
  * Node Name: `http://localhost:3001/alumnos/2420002/actuator/health`
  * Method: `GET`
  * Parameter: ``
  * Attack: ``
  * Evidence: `404`
  * Other Info: ``
* URL: http://localhost:3001/alumnos/2420002/calificaciones
  * Node Name: `http://localhost:3001/alumnos/2420002/calificaciones`
  * Method: `GET`
  * Parameter: ``
  * Attack: ``
  * Evidence: `403`
  * Other Info: ``
* URL: http://localhost:3001/alumnos/2420002/calificaciones/
  * Node Name: `http://localhost:3001/alumnos/2420002/calificaciones/`
  * Method: `GET`
  * Parameter: ``
  * Attack: ``
  * Evidence: `403`
  * Other Info: ``
* URL: http://localhost:3001/alumnos/2420002/cuenta
  * Node Name: `http://localhost:3001/alumnos/2420002/cuenta`
  * Method: `GET`
  * Parameter: ``
  * Attack: ``
  * Evidence: `403`
  * Other Info: ``
* URL: http://localhost:3001/alumnos/2420002/cuenta/
  * Node Name: `http://localhost:3001/alumnos/2420002/cuenta/`
  * Method: `GET`
  * Parameter: ``
  * Attack: ``
  * Evidence: `403`
  * Other Info: ``
* URL: http://localhost:3001/alumnos/2420002/inscripciones
  * Node Name: `http://localhost:3001/alumnos/2420002/inscripciones`
  * Method: `GET`
  * Parameter: ``
  * Attack: ``
  * Evidence: `403`
  * Other Info: ``
* URL: http://localhost:3001/alumnos/2420002/inscripciones/
  * Node Name: `http://localhost:3001/alumnos/2420002/inscripciones/`
  * Method: `GET`
  * Parameter: ``
  * Attack: ``
  * Evidence: `403`
  * Other Info: ``
* URL: http://localhost:3001/alumnos/2500419365215257910
  * Node Name: `http://localhost:3001/alumnos/2500419365215257910`
  * Method: `GET`
  * Parameter: ``
  * Attack: ``
  * Evidence: `403`
  * Other Info: ``
* URL: http://localhost:3001/documentos
  * Node Name: `http://localhost:3001/documentos`
  * Method: `GET`
  * Parameter: ``
  * Attack: ``
  * Evidence: `404`
  * Other Info: ``
* URL: http://localhost:3001/documentos/
  * Node Name: `http://localhost:3001/documentos/`
  * Method: `GET`
  * Parameter: ``
  * Attack: ``
  * Evidence: `404`
  * Other Info: ``
* URL: http://localhost:3001/documentos/1578291914653911474
  * Node Name: `http://localhost:3001/documentos/1578291914653911474`
  * Method: `GET`
  * Parameter: ``
  * Attack: ``
  * Evidence: `403`
  * Other Info: ``
* URL: http://localhost:3001/documentos/DOC-2420002-98ABD7CD
  * Node Name: `http://localhost:3001/documentos/DOC-2420002-98ABD7CD`
  * Method: `GET`
  * Parameter: ``
  * Attack: ``
  * Evidence: `403`
  * Other Info: ``
* URL: http://localhost:3001/documentos/DOC-2420002-98ABD7CD/
  * Node Name: `http://localhost:3001/documentos/DOC-2420002-98ABD7CD/`
  * Method: `GET`
  * Parameter: ``
  * Attack: ``
  * Evidence: `403`
  * Other Info: ``
* URL: http://localhost:3001/inscripciones
  * Node Name: `http://localhost:3001/inscripciones`
  * Method: `GET`
  * Parameter: ``
  * Attack: ``
  * Evidence: `404`
  * Other Info: ``
* URL: http://localhost:3001/inscripciones/
  * Node Name: `http://localhost:3001/inscripciones/`
  * Method: `GET`
  * Parameter: ``
  * Attack: ``
  * Evidence: `404`
  * Other Info: ``
* URL: http://localhost:3001/inscripciones/8295016901182076097
  * Node Name: `http://localhost:3001/inscripciones/8295016901182076097`
  * Method: `GET`
  * Parameter: ``
  * Attack: ``
  * Evidence: `404`
  * Other Info: ``
* URL: http://localhost:3001/inscripciones/INS-2026B-2420002
  * Node Name: `http://localhost:3001/inscripciones/INS-2026B-2420002`
  * Method: `GET`
  * Parameter: ``
  * Attack: ``
  * Evidence: `404`
  * Other Info: ``
* URL: http://localhost:3001/inscripciones/INS-2026B-2420002/
  * Node Name: `http://localhost:3001/inscripciones/INS-2026B-2420002/`
  * Method: `GET`
  * Parameter: ``
  * Attack: ``
  * Evidence: `404`
  * Other Info: ``
* URL: http://localhost:3001/inscripciones/INS-2026B-2420002/7930131851144412242
  * Node Name: `http://localhost:3001/inscripciones/INS-2026B-2420002/7930131851144412242`
  * Method: `GET`
  * Parameter: ``
  * Attack: ``
  * Evidence: `404`
  * Other Info: ``
* URL: http://localhost:3001/pagos
  * Node Name: `http://localhost:3001/pagos`
  * Method: `GET`
  * Parameter: ``
  * Attack: ``
  * Evidence: `403`
  * Other Info: ``
* URL: http://localhost:3001/pagos/
  * Node Name: `http://localhost:3001/pagos/`
  * Method: `GET`
  * Parameter: ``
  * Attack: ``
  * Evidence: `403`
  * Other Info: ``
* URL: http://localhost:3001/pagos/1
  * Node Name: `http://localhost:3001/pagos/1`
  * Method: `GET`
  * Parameter: ``
  * Attack: ``
  * Evidence: `404`
  * Other Info: ``
* URL: http://localhost:3001/pagos/1/
  * Node Name: `http://localhost:3001/pagos/1/`
  * Method: `GET`
  * Parameter: ``
  * Attack: ``
  * Evidence: `404`
  * Other Info: ``
* URL: http://localhost:3001/pagos/2
  * Node Name: `http://localhost:3001/pagos/2`
  * Method: `GET`
  * Parameter: ``
  * Attack: ``
  * Evidence: `404`
  * Other Info: ``
* URL: http://localhost:3001/pagos/2/
  * Node Name: `http://localhost:3001/pagos/2/`
  * Method: `GET`
  * Parameter: ``
  * Attack: ``
  * Evidence: `404`
  * Other Info: ``
* URL: http://localhost:3001/pagos/2/4998659720530091208
  * Node Name: `http://localhost:3001/pagos/2/4998659720530091208`
  * Method: `GET`
  * Parameter: ``
  * Attack: ``
  * Evidence: `404`
  * Other Info: ``
* URL: http://localhost:3001/pagos/2502989727167238103
  * Node Name: `http://localhost:3001/pagos/2502989727167238103`
  * Method: `GET`
  * Parameter: ``
  * Attack: ``
  * Evidence: `400`
  * Other Info: ``
* URL: http://localhost:3001/tramites
  * Node Name: `http://localhost:3001/tramites`
  * Method: `GET`
  * Parameter: ``
  * Attack: ``
  * Evidence: `403`
  * Other Info: ``
* URL: http://localhost:3001/tramites/
  * Node Name: `http://localhost:3001/tramites/`
  * Method: `GET`
  * Parameter: ``
  * Attack: ``
  * Evidence: `403`
  * Other Info: ``
* URL: http://localhost:3001/tramites/1908194827649465295
  * Node Name: `http://localhost:3001/tramites/1908194827649465295`
  * Method: `GET`
  * Parameter: ``
  * Attack: ``
  * Evidence: `404`
  * Other Info: ``
* URL: http://localhost:3001/tramites/TRA-2420002-98ABD7CD
  * Node Name: `http://localhost:3001/tramites/TRA-2420002-98ABD7CD`
  * Method: `GET`
  * Parameter: ``
  * Attack: ``
  * Evidence: `404`
  * Other Info: ``
* URL: http://localhost:3001/tramites/TRA-2420002-98ABD7CD/
  * Node Name: `http://localhost:3001/tramites/TRA-2420002-98ABD7CD/`
  * Method: `GET`
  * Parameter: ``
  * Attack: ``
  * Evidence: `404`
  * Other Info: ``
* URL: http://localhost:3001/tramites/TRA-2420002-98ABD7CD/5734224314368356268
  * Node Name: `http://localhost:3001/tramites/TRA-2420002-98ABD7CD/5734224314368356268`
  * Method: `GET`
  * Parameter: ``
  * Attack: ``
  * Evidence: `404`
  * Other Info: ``
* URL: http://localhost:3001/tramites/TRA-2420002-98ABD7CD/documento
  * Node Name: `http://localhost:3001/tramites/TRA-2420002-98ABD7CD/documento`
  * Method: `GET`
  * Parameter: ``
  * Attack: ``
  * Evidence: `404`
  * Other Info: ``
* URL: http://localhost:3001/tramites/TRA-2420002-98ABD7CD/documento/
  * Node Name: `http://localhost:3001/tramites/TRA-2420002-98ABD7CD/documento/`
  * Method: `GET`
  * Parameter: ``
  * Attack: ``
  * Evidence: `404`
  * Other Info: ``
* URL: http://localhost:3001/usuarios
  * Node Name: `http://localhost:3001/usuarios`
  * Method: `GET`
  * Parameter: ``
  * Attack: ``
  * Evidence: `403`
  * Other Info: ``
* URL: http://localhost:3001/usuarios/
  * Node Name: `http://localhost:3001/usuarios/`
  * Method: `GET`
  * Parameter: ``
  * Attack: ``
  * Evidence: `403`
  * Other Info: ``
* URL: http://localhost:3001/usuarios/6557696187509013265
  * Node Name: `http://localhost:3001/usuarios/6557696187509013265`
  * Method: `GET`
  * Parameter: ``
  * Attack: ``
  * Evidence: `404`
  * Other Info: ``
* URL: http://localhost:3001/usuarios/fc871272-6951-46ba-ad74-429dc94d303e
  * Node Name: `http://localhost:3001/usuarios/fc871272-6951-46ba-ad74-429dc94d303e ()({confirmacion,activo,roles:[]})`
  * Method: `PATCH`
  * Parameter: ``
  * Attack: ``
  * Evidence: `403`
  * Other Info: ``
* URL: http://localhost:3001/usuarios/fc871272-6951-46ba-ad74-429dc94d303e/
  * Node Name: `http://localhost:3001/usuarios/fc871272-6951-46ba-ad74-429dc94d303e/ ()({confirmacion,activo,roles:[]})`
  * Method: `PATCH`
  * Parameter: ``
  * Attack: ``
  * Evidence: `403`
  * Other Info: ``
* URL: http://localhost:3001/alumnos/2420002/becas
  * Node Name: `http://localhost:3001/alumnos/2420002/becas ()({importe,concepto})`
  * Method: `POST`
  * Parameter: ``
  * Attack: ``
  * Evidence: `403`
  * Other Info: ``
* URL: http://localhost:3001/alumnos/2420002/becas/
  * Node Name: `http://localhost:3001/alumnos/2420002/becas/ ()({importe,concepto})`
  * Method: `POST`
  * Parameter: ``
  * Attack: ``
  * Evidence: `403`
  * Other Info: ``
* URL: http://localhost:3001/computeMetadata/v1/
  * Node Name: `http://localhost:3001/computeMetadata/v1/ ()({importe,concepto})`
  * Method: `POST`
  * Parameter: ``
  * Attack: ``
  * Evidence: `404`
  * Other Info: ``
* URL: http://localhost:3001/latest/meta-data/
  * Node Name: `http://localhost:3001/latest/meta-data/ ()({importe,concepto})`
  * Method: `POST`
  * Parameter: ``
  * Attack: ``
  * Evidence: `404`
  * Other Info: ``
* URL: http://localhost:3001/metadata/instance
  * Node Name: `http://localhost:3001/metadata/instance ()({importe,concepto})`
  * Method: `POST`
  * Parameter: ``
  * Attack: ``
  * Evidence: `404`
  * Other Info: ``
* URL: http://localhost:3001/metadata/v1
  * Node Name: `http://localhost:3001/metadata/v1 ()({importe,concepto})`
  * Method: `POST`
  * Parameter: ``
  * Attack: ``
  * Evidence: `404`
  * Other Info: ``
* URL: http://localhost:3001/opc/v1/instance/
  * Node Name: `http://localhost:3001/opc/v1/instance/ ()({importe,concepto})`
  * Method: `POST`
  * Parameter: ``
  * Attack: ``
  * Evidence: `404`
  * Other Info: ``
* URL: http://localhost:3001/opc/v2/instance/
  * Node Name: `http://localhost:3001/opc/v2/instance/ ()({importe,concepto})`
  * Method: `POST`
  * Parameter: ``
  * Attack: ``
  * Evidence: `404`
  * Other Info: ``
* URL: http://localhost:3001/openstack/latest/meta_data.json
  * Node Name: `http://localhost:3001/openstack/latest/meta_data.json ()({importe,concepto})`
  * Method: `POST`
  * Parameter: ``
  * Attack: ``
  * Evidence: `404`
  * Other Info: ``
* URL: http://localhost:3001/pagos/2/simulacion
  * Node Name: `http://localhost:3001/pagos/2/simulacion ()({resultado})`
  * Method: `POST`
  * Parameter: ``
  * Attack: ``
  * Evidence: `400`
  * Other Info: ``
* URL: http://localhost:3001/pagos/2/simulacion
  * Node Name: `http://localhost:3001/pagos/2/simulacion ()({resultado})`
  * Method: `POST`
  * Parameter: ``
  * Attack: ``
  * Evidence: `404`
  * Other Info: ``
* URL: http://localhost:3001/pagos/2/simulacion/
  * Node Name: `http://localhost:3001/pagos/2/simulacion/ ()({resultado})`
  * Method: `POST`
  * Parameter: ``
  * Attack: ``
  * Evidence: `404`
  * Other Info: ``
* URL: http://localhost:3001/tramites/TRA-2420002-98ABD7CD/emision
  * Node Name: `http://localhost:3001/tramites/TRA-2420002-98ABD7CD/emision`
  * Method: `POST`
  * Parameter: ``
  * Attack: ``
  * Evidence: `403`
  * Other Info: ``
* URL: http://localhost:3001/tramites/TRA-2420002-98ABD7CD/emision/
  * Node Name: `http://localhost:3001/tramites/TRA-2420002-98ABD7CD/emision/`
  * Method: `POST`
  * Parameter: ``
  * Attack: ``
  * Evidence: `403`
  * Other Info: ``
* URL: http://localhost:3001/tramites/TRA-2420002-98ABD7CD/proceso
  * Node Name: `http://localhost:3001/tramites/TRA-2420002-98ABD7CD/proceso`
  * Method: `POST`
  * Parameter: ``
  * Attack: ``
  * Evidence: `403`
  * Other Info: ``
* URL: http://localhost:3001/tramites/TRA-2420002-98ABD7CD/proceso/
  * Node Name: `http://localhost:3001/tramites/TRA-2420002-98ABD7CD/proceso/`
  * Method: `POST`
  * Parameter: ``
  * Attack: ``
  * Evidence: `403`
  * Other Info: ``
* URL: http://localhost:3001/tramites/TRA-2420002-98ABD7CD/rechazo
  * Node Name: `http://localhost:3001/tramites/TRA-2420002-98ABD7CD/rechazo ()({motivo})`
  * Method: `POST`
  * Parameter: ``
  * Attack: ``
  * Evidence: `403`
  * Other Info: ``
* URL: http://localhost:3001/tramites/TRA-2420002-98ABD7CD/rechazo/
  * Node Name: `http://localhost:3001/tramites/TRA-2420002-98ABD7CD/rechazo/ ()({motivo})`
  * Method: `POST`
  * Parameter: ``
  * Attack: ``
  * Evidence: `403`
  * Other Info: ``
* URL: http://localhost:3001/alumnos/2420002/cuenta
  * Node Name: `http://localhost:3001/alumnos/2420002/cuenta ()({correo})`
  * Method: `PUT`
  * Parameter: ``
  * Attack: ``
  * Evidence: `403`
  * Other Info: ``
* URL: http://localhost:3001/alumnos/2420002/cuenta/
  * Node Name: `http://localhost:3001/alumnos/2420002/cuenta/ ()({correo})`
  * Method: `PUT`
  * Parameter: ``
  * Attack: ``
  * Evidence: `403`
  * Other Info: ``
* URL: http://localhost:3001/alumnos/2420002/estatus
  * Node Name: `http://localhost:3001/alumnos/2420002/estatus ()({estatus})`
  * Method: `PUT`
  * Parameter: ``
  * Attack: ``
  * Evidence: `403`
  * Other Info: ``
* URL: http://localhost:3001/alumnos/2420002/estatus/
  * Node Name: `http://localhost:3001/alumnos/2420002/estatus/ ()({estatus})`
  * Method: `PUT`
  * Parameter: ``
  * Attack: ``
  * Evidence: `403`
  * Other Info: ``
* URL: http://localhost:3001/alumnos/2420002/facultad
  * Node Name: `http://localhost:3001/alumnos/2420002/facultad ()({facultadClave})`
  * Method: `PUT`
  * Parameter: ``
  * Attack: ``
  * Evidence: `403`
  * Other Info: ``
* URL: http://localhost:3001/alumnos/2420002/facultad/
  * Node Name: `http://localhost:3001/alumnos/2420002/facultad/ ()({facultadClave})`
  * Method: `PUT`
  * Parameter: ``
  * Attack: ``
  * Evidence: `403`
  * Other Info: ``
* URL: http://localhost:3001/inscripciones/INS-2026B-2420002/grupos
  * Node Name: `http://localhost:3001/inscripciones/INS-2026B-2420002/grupos ()({grupos:[]})`
  * Method: `PUT`
  * Parameter: ``
  * Attack: ``
  * Evidence: `400`
  * Other Info: ``
* URL: http://localhost:3001/inscripciones/INS-2026B-2420002/grupos
  * Node Name: `http://localhost:3001/inscripciones/INS-2026B-2420002/grupos ()({grupos:[{}]})`
  * Method: `PUT`
  * Parameter: ``
  * Attack: ``
  * Evidence: `404`
  * Other Info: ``
* URL: http://localhost:3001/inscripciones/INS-2026B-2420002/grupos/
  * Node Name: `http://localhost:3001/inscripciones/INS-2026B-2420002/grupos/ ()({grupos:[{}]})`
  * Method: `PUT`
  * Parameter: ``
  * Attack: ``
  * Evidence: `404`
  * Other Info: ``


Instances: 75

### Solution



### Reference



#### CWE Id: [ 388 ](https://cwe.mitre.org/data/definitions/388.html)


#### WASC Id: 20

#### Source ID: 4

### [ Non-Storable Content ](https://www.zaproxy.org/docs/alerts/10049/)



##### Informational (Medium)

### Description

The response contents are not storable by caching components such as proxy servers. If the response does not contain sensitive, personal or user-specific information, it may benefit from being stored and cached, to improve performance.

* URL: http://localhost:3001/alumnos/2420002
  * Node Name: `http://localhost:3001/alumnos/2420002`
  * Method: `GET`
  * Parameter: ``
  * Attack: ``
  * Evidence: `no-store`
  * Other Info: ``
* URL: http://localhost:3001/alumnos/2420002/calificaciones
  * Node Name: `http://localhost:3001/alumnos/2420002/calificaciones`
  * Method: `GET`
  * Parameter: ``
  * Attack: ``
  * Evidence: `no-store`
  * Other Info: ``
* URL: http://localhost:3001/alumnos/2420002/cuenta
  * Node Name: `http://localhost:3001/alumnos/2420002/cuenta`
  * Method: `GET`
  * Parameter: ``
  * Attack: ``
  * Evidence: `no-store`
  * Other Info: ``
* URL: http://localhost:3001/alumnos/2420002/becas
  * Node Name: `http://localhost:3001/alumnos/2420002/becas ()({importe,concepto})`
  * Method: `POST`
  * Parameter: ``
  * Attack: ``
  * Evidence: `no-store`
  * Other Info: ``
* URL: http://localhost:3001/alumnos/2420002/estatus
  * Node Name: `http://localhost:3001/alumnos/2420002/estatus ()({estatus})`
  * Method: `PUT`
  * Parameter: ``
  * Attack: ``
  * Evidence: `PUT `
  * Other Info: ``

Instances: Systemic


### Solution

The content may be marked as storable by ensuring that the following conditions are satisfied:
The request method must be understood by the cache and defined as being cacheable ("GET", "HEAD", and "POST" are currently defined as cacheable)
The response status code must be understood by the cache (one of the 1XX, 2XX, 3XX, 4XX, or 5XX response classes are generally understood)
The "no-store" cache directive must not appear in the request or response header fields
For caching by "shared" caches such as "proxy" caches, the "private" response directive must not appear in the response
For caching by "shared" caches such as "proxy" caches, the "Authorization" header field must not appear in the request, unless the response explicitly allows it (using one of the "must-revalidate", "public", or "s-maxage" Cache-Control response directives)
In addition to the conditions above, at least one of the following conditions must also be satisfied by the response:
It must contain an "Expires" header field
It must contain a "max-age" response directive
For "shared" caches such as "proxy" caches, it must contain a "s-maxage" response directive
It must contain a "Cache Control Extension" that allows it to be cached
It must have a status code that is defined as cacheable by default (200, 203, 204, 206, 300, 301, 404, 405, 410, 414, 501).

### Reference


* [ https://datatracker.ietf.org/doc/html/rfc7234 ](https://datatracker.ietf.org/doc/html/rfc7234)
* [ https://datatracker.ietf.org/doc/html/rfc7231 ](https://datatracker.ietf.org/doc/html/rfc7231)
* [ https://www.w3.org/Protocols/rfc2616/rfc2616-sec13.html ](https://www.w3.org/Protocols/rfc2616/rfc2616-sec13.html)


#### CWE Id: [ 524 ](https://cwe.mitre.org/data/definitions/524.html)


#### WASC Id: 13

#### Source ID: 3


