# ZAP Scanning Report

ZAP by [Checkmarx](https://checkmarx.com/).


## Summary of Alerts

| Risk Level | Number of Alerts |
| --- | --- |
| High | 0 |
| Medium | 0 |
| Low | 0 |
| Informational | 3 |




## Insights

| Level | Reason | Site | Description | Statistic |
| --- | --- | --- | --- | --- |
| Medium | Exceeded High | http://localhost:3001 | Percentage of responses with status code 4xx | 97 % |
| Info | Informational | http://localhost:3001 | Percentage of responses with status code 2xx | 2 % |
| Info | Informational | http://localhost:3001 | Percentage of endpoints with content type application/json | 100 % |
| Info | Informational | http://localhost:3001 | Percentage of endpoints with method GET | 69 % |
| Info | Informational | http://localhost:3001 | Percentage of endpoints with method POST | 15 % |
| Info | Informational | http://localhost:3001 | Percentage of endpoints with method PUT | 14 % |
| Info | Informational | http://localhost:3001 | Count of total endpoints | 69    |







## Alerts

| Name | Risk Level | Number of Instances |
| --- | --- | --- |
| A Client Error response code was returned by the server | Informational | 59 |
| Non-Storable Content | Informational | Systemic |
| Session Management Response Identified | Informational | 1 |




## Alert Detail



### [ A Client Error response code was returned by the server ](https://www.zaproxy.org/docs/alerts/100000/)



##### Informational (High)

### Description

A response code of 400 was returned by the server.
This may indicate that the application is failing to handle unexpected input correctly.
Raised by the 'Alert on HTTP Response Code Error' script

* URL: http://localhost:3001
  * Node Name: `http://localhost:3001`
  * Method: `GET`
  * Parameter: ``
  * Attack: ``
  * Evidence: `404`
  * Other Info: ``
* URL: http://localhost:3001/
  * Node Name: `http://localhost:3001/`
  * Method: `GET`
  * Parameter: ``
  * Attack: ``
  * Evidence: `404`
  * Other Info: ``
* URL: http://localhost:3001/1404383925109839542
  * Node Name: `http://localhost:3001/1404383925109839542`
  * Method: `GET`
  * Parameter: ``
  * Attack: ``
  * Evidence: `404`
  * Other Info: ``
* URL: http://localhost:3001/alumnos
  * Node Name: `http://localhost:3001/alumnos`
  * Method: `GET`
  * Parameter: ``
  * Attack: ``
  * Evidence: `403`
  * Other Info: ``
* URL: http://localhost:3001/alumnos/
  * Node Name: `http://localhost:3001/alumnos/`
  * Method: `GET`
  * Parameter: ``
  * Attack: ``
  * Evidence: `403`
  * Other Info: ``
* URL: http://localhost:3001/alumnos/952609297584570228
  * Node Name: `http://localhost:3001/alumnos/952609297584570228`
  * Method: `GET`
  * Parameter: ``
  * Attack: ``
  * Evidence: `403`
  * Other Info: ``
* URL: http://localhost:3001/alumnos/actual/1346999072000073086
  * Node Name: `http://localhost:3001/alumnos/actual/1346999072000073086`
  * Method: `GET`
  * Parameter: ``
  * Attack: ``
  * Evidence: `404`
  * Other Info: ``
* URL: http://localhost:3001/grupos
  * Node Name: `http://localhost:3001/grupos`
  * Method: `GET`
  * Parameter: ``
  * Attack: ``
  * Evidence: `400`
  * Other Info: ``
* URL: http://localhost:3001/grupos%3Fperiodo=http%253A%252F%252Fwww.google.com%252F
  * Node Name: `http://localhost:3001/grupos (periodo)`
  * Method: `GET`
  * Parameter: ``
  * Attack: ``
  * Evidence: `400`
  * Other Info: ``
* URL: http://localhost:3001/grupos/
  * Node Name: `http://localhost:3001/grupos/`
  * Method: `GET`
  * Parameter: ``
  * Attack: ``
  * Evidence: `400`
  * Other Info: ``
* URL: http://localhost:3001/grupos/1495989881046009534
  * Node Name: `http://localhost:3001/grupos/1495989881046009534`
  * Method: `GET`
  * Parameter: ``
  * Attack: ``
  * Evidence: `404`
  * Other Info: ``
* URL: http://localhost:3001/grupos/choques%3Fgrupos=%255B1,2%255D
  * Node Name: `http://localhost:3001/grupos/choques (grupos)`
  * Method: `GET`
  * Parameter: ``
  * Attack: ``
  * Evidence: `400`
  * Other Info: ``
* URL: http://localhost:3001/grupos/choques/
  * Node Name: `http://localhost:3001/grupos/choques/`
  * Method: `GET`
  * Parameter: ``
  * Attack: ``
  * Evidence: `400`
  * Other Info: ``
* URL: http://localhost:3001/inscripciones
  * Node Name: `http://localhost:3001/inscripciones`
  * Method: `GET`
  * Parameter: ``
  * Attack: ``
  * Evidence: `404`
  * Other Info: ``
* URL: http://localhost:3001/inscripciones/
  * Node Name: `http://localhost:3001/inscripciones/`
  * Method: `GET`
  * Parameter: ``
  * Attack: ``
  * Evidence: `404`
  * Other Info: ``
* URL: http://localhost:3001/inscripciones/2541538255999586556
  * Node Name: `http://localhost:3001/inscripciones/2541538255999586556`
  * Method: `GET`
  * Parameter: ``
  * Attack: ``
  * Evidence: `404`
  * Other Info: ``
* URL: http://localhost:3001/inscripciones/ISW-101
  * Node Name: `http://localhost:3001/inscripciones/ISW-101`
  * Method: `GET`
  * Parameter: ``
  * Attack: ``
  * Evidence: `404`
  * Other Info: ``
* URL: http://localhost:3001/inscripciones/ISW-101/
  * Node Name: `http://localhost:3001/inscripciones/ISW-101/`
  * Method: `GET`
  * Parameter: ``
  * Attack: ``
  * Evidence: `404`
  * Other Info: ``
* URL: http://localhost:3001/inscripciones/ISW-101/7361827311432641673
  * Node Name: `http://localhost:3001/inscripciones/ISW-101/7361827311432641673`
  * Method: `GET`
  * Parameter: ``
  * Attack: ``
  * Evidence: `404`
  * Other Info: ``
* URL: http://localhost:3001/inscripciones/ISW-101/actuator/health
  * Node Name: `http://localhost:3001/inscripciones/ISW-101/actuator/health`
  * Method: `GET`
  * Parameter: ``
  * Attack: ``
  * Evidence: `404`
  * Other Info: ``
* URL: http://localhost:3001/pagos
  * Node Name: `http://localhost:3001/pagos`
  * Method: `GET`
  * Parameter: ``
  * Attack: ``
  * Evidence: `403`
  * Other Info: ``
* URL: http://localhost:3001/pagos/
  * Node Name: `http://localhost:3001/pagos/`
  * Method: `GET`
  * Parameter: ``
  * Attack: ``
  * Evidence: `403`
  * Other Info: ``
* URL: http://localhost:3001/pagos/1.2
  * Node Name: `http://localhost:3001/pagos/1.2`
  * Method: `GET`
  * Parameter: ``
  * Attack: ``
  * Evidence: `400`
  * Other Info: ``
* URL: http://localhost:3001/pagos/1.2/
  * Node Name: `http://localhost:3001/pagos/1.2/`
  * Method: `GET`
  * Parameter: ``
  * Attack: ``
  * Evidence: `400`
  * Other Info: ``
* URL: http://localhost:3001/pagos/1.2/6370281791813456125
  * Node Name: `http://localhost:3001/pagos/1.2/6370281791813456125`
  * Method: `GET`
  * Parameter: ``
  * Attack: ``
  * Evidence: `404`
  * Other Info: ``
* URL: http://localhost:3001/pagos/5811554873756803270
  * Node Name: `http://localhost:3001/pagos/5811554873756803270`
  * Method: `GET`
  * Parameter: ``
  * Attack: ``
  * Evidence: `400`
  * Other Info: ``
* URL: http://localhost:3001/sesiones
  * Node Name: `http://localhost:3001/sesiones`
  * Method: `GET`
  * Parameter: ``
  * Attack: ``
  * Evidence: `404`
  * Other Info: ``
* URL: http://localhost:3001/sesiones/
  * Node Name: `http://localhost:3001/sesiones/`
  * Method: `GET`
  * Parameter: ``
  * Attack: ``
  * Evidence: `404`
  * Other Info: ``
* URL: http://localhost:3001/sesiones/7453943057542634891
  * Node Name: `http://localhost:3001/sesiones/7453943057542634891`
  * Method: `GET`
  * Parameter: ``
  * Attack: ``
  * Evidence: `404`
  * Other Info: ``
* URL: http://localhost:3001/sesiones/actual/1655351705247450271
  * Node Name: `http://localhost:3001/sesiones/actual/1655351705247450271`
  * Method: `GET`
  * Parameter: ``
  * Attack: ``
  * Evidence: `404`
  * Other Info: ``
* URL: http://localhost:3001/tramites
  * Node Name: `http://localhost:3001/tramites`
  * Method: `GET`
  * Parameter: ``
  * Attack: ``
  * Evidence: `403`
  * Other Info: ``
* URL: http://localhost:3001/tramites/
  * Node Name: `http://localhost:3001/tramites/`
  * Method: `GET`
  * Parameter: ``
  * Attack: ``
  * Evidence: `403`
  * Other Info: ``
* URL: http://localhost:3001/tramites/7468163294095710204
  * Node Name: `http://localhost:3001/tramites/7468163294095710204`
  * Method: `GET`
  * Parameter: ``
  * Attack: ``
  * Evidence: `404`
  * Other Info: ``
* URL: http://localhost:3001/tramites/TRA-2420001-1A2B3C4D
  * Node Name: `http://localhost:3001/tramites/TRA-2420001-1A2B3C4D`
  * Method: `GET`
  * Parameter: ``
  * Attack: ``
  * Evidence: `404`
  * Other Info: ``
* URL: http://localhost:3001/tramites/TRA-2420001-1A2B3C4D/
  * Node Name: `http://localhost:3001/tramites/TRA-2420001-1A2B3C4D/`
  * Method: `GET`
  * Parameter: ``
  * Attack: ``
  * Evidence: `404`
  * Other Info: ``
* URL: http://localhost:3001/tramites/TRA-2420001-1A2B3C4D/245085128371326703
  * Node Name: `http://localhost:3001/tramites/TRA-2420001-1A2B3C4D/245085128371326703`
  * Method: `GET`
  * Parameter: ``
  * Attack: ``
  * Evidence: `404`
  * Other Info: ``
* URL: http://localhost:3001/tramites/TRA-2420001-1A2B3C4D/documento
  * Node Name: `http://localhost:3001/tramites/TRA-2420001-1A2B3C4D/documento`
  * Method: `GET`
  * Parameter: ``
  * Attack: ``
  * Evidence: `404`
  * Other Info: ``
* URL: http://localhost:3001/tramites/TRA-2420001-1A2B3C4D/documento/
  * Node Name: `http://localhost:3001/tramites/TRA-2420001-1A2B3C4D/documento/`
  * Method: `GET`
  * Parameter: ``
  * Attack: ``
  * Evidence: `404`
  * Other Info: ``
* URL: http://localhost:3001/inscripciones
  * Node Name: `http://localhost:3001/inscripciones ()({grupos:[],periodoClave})`
  * Method: `POST`
  * Parameter: ``
  * Attack: ``
  * Evidence: `400`
  * Other Info: ``
* URL: http://localhost:3001/inscripciones
  * Node Name: `http://localhost:3001/inscripciones ()({grupos:[{}],periodoClave})`
  * Method: `POST`
  * Parameter: ``
  * Attack: ``
  * Evidence: `400`
  * Other Info: ``
* URL: http://localhost:3001/inscripciones/
  * Node Name: `http://localhost:3001/inscripciones/ ()({grupos:[{}],periodoClave})`
  * Method: `POST`
  * Parameter: ``
  * Attack: ``
  * Evidence: `400`
  * Other Info: ``
* URL: http://localhost:3001/pagos
  * Node Name: `http://localhost:3001/pagos ()({importe})`
  * Method: `POST`
  * Parameter: ``
  * Attack: ``
  * Evidence: `400`
  * Other Info: ``
* URL: http://localhost:3001/pagos
  * Node Name: `http://localhost:3001/pagos ()({importe})`
  * Method: `POST`
  * Parameter: ``
  * Attack: ``
  * Evidence: `409`
  * Other Info: ``
* URL: http://localhost:3001/pagos/
  * Node Name: `http://localhost:3001/pagos/ ()({importe})`
  * Method: `POST`
  * Parameter: ``
  * Attack: ``
  * Evidence: `409`
  * Other Info: ``
* URL: http://localhost:3001/pagos/1.2/simulacion
  * Node Name: `http://localhost:3001/pagos/1.2/simulacion ()({resultado})`
  * Method: `POST`
  * Parameter: ``
  * Attack: ``
  * Evidence: `400`
  * Other Info: ``
* URL: http://localhost:3001/pagos/1.2/simulacion/
  * Node Name: `http://localhost:3001/pagos/1.2/simulacion/ ()({resultado})`
  * Method: `POST`
  * Parameter: ``
  * Attack: ``
  * Evidence: `400`
  * Other Info: ``
* URL: http://localhost:3001/sesiones
  * Node Name: `http://localhost:3001/sesiones ()({correo,contrasena})`
  * Method: `POST`
  * Parameter: ``
  * Attack: ``
  * Evidence: `400`
  * Other Info: ``
* URL: http://localhost:3001/sesiones/
  * Node Name: `http://localhost:3001/sesiones/ ()({correo,contrasena})`
  * Method: `POST`
  * Parameter: ``
  * Attack: ``
  * Evidence: `400`
  * Other Info: ``
* URL: http://localhost:3001/tramites
  * Node Name: `http://localhost:3001/tramites ()({tipo})`
  * Method: `POST`
  * Parameter: ``
  * Attack: ``
  * Evidence: `400`
  * Other Info: ``
* URL: http://localhost:3001/computeMetadata/v1/
  * Node Name: `http://localhost:3001/computeMetadata/v1/ ()({grupos:[{}]})`
  * Method: `PUT`
  * Parameter: ``
  * Attack: ``
  * Evidence: `404`
  * Other Info: ``
* URL: http://localhost:3001/inscripciones/ISW-101/grupos
  * Node Name: `http://localhost:3001/inscripciones/ISW-101/grupos ()({grupos:[]})`
  * Method: `PUT`
  * Parameter: ``
  * Attack: ``
  * Evidence: `400`
  * Other Info: ``
* URL: http://localhost:3001/inscripciones/ISW-101/grupos
  * Node Name: `http://localhost:3001/inscripciones/ISW-101/grupos ()({grupos:[{}]})`
  * Method: `PUT`
  * Parameter: ``
  * Attack: ``
  * Evidence: `400`
  * Other Info: ``
* URL: http://localhost:3001/inscripciones/ISW-101/grupos/
  * Node Name: `http://localhost:3001/inscripciones/ISW-101/grupos/ ()({grupos:[{}]})`
  * Method: `PUT`
  * Parameter: ``
  * Attack: ``
  * Evidence: `400`
  * Other Info: ``
* URL: http://localhost:3001/latest/meta-data/
  * Node Name: `http://localhost:3001/latest/meta-data/ ()({grupos:[{}]})`
  * Method: `PUT`
  * Parameter: ``
  * Attack: ``
  * Evidence: `404`
  * Other Info: ``
* URL: http://localhost:3001/metadata/instance
  * Node Name: `http://localhost:3001/metadata/instance ()({grupos:[{}]})`
  * Method: `PUT`
  * Parameter: ``
  * Attack: ``
  * Evidence: `404`
  * Other Info: ``
* URL: http://localhost:3001/metadata/v1
  * Node Name: `http://localhost:3001/metadata/v1 ()({grupos:[{}]})`
  * Method: `PUT`
  * Parameter: ``
  * Attack: ``
  * Evidence: `404`
  * Other Info: ``
* URL: http://localhost:3001/opc/v1/instance/
  * Node Name: `http://localhost:3001/opc/v1/instance/ ()({grupos:[{}]})`
  * Method: `PUT`
  * Parameter: ``
  * Attack: ``
  * Evidence: `404`
  * Other Info: ``
* URL: http://localhost:3001/opc/v2/instance/
  * Node Name: `http://localhost:3001/opc/v2/instance/ ()({grupos:[{}]})`
  * Method: `PUT`
  * Parameter: ``
  * Attack: ``
  * Evidence: `404`
  * Other Info: ``
* URL: http://localhost:3001/openstack/latest/meta_data.json
  * Node Name: `http://localhost:3001/openstack/latest/meta_data.json ()({grupos:[{}]})`
  * Method: `PUT`
  * Parameter: ``
  * Attack: ``
  * Evidence: `404`
  * Other Info: ``


Instances: 59

### Solution



### Reference



#### CWE Id: [ 388 ](https://cwe.mitre.org/data/definitions/388.html)


#### WASC Id: 20

#### Source ID: 4

### [ Non-Storable Content ](https://www.zaproxy.org/docs/alerts/10049/)



##### Informational (Medium)

### Description

The response contents are not storable by caching components such as proxy servers. If the response does not contain sensitive, personal or user-specific information, it may benefit from being stored and cached, to improve performance.

* URL: http://localhost:3001/planes
  * Node Name: `http://localhost:3001/planes`
  * Method: `GET`
  * Parameter: ``
  * Attack: ``
  * Evidence: `no-store`
  * Other Info: ``
* URL: http://localhost:3001/salud
  * Node Name: `http://localhost:3001/salud`
  * Method: `GET`
  * Parameter: ``
  * Attack: ``
  * Evidence: `no-store`
  * Other Info: ``
* URL: http://localhost:3001/sesiones/actual
  * Node Name: `http://localhost:3001/sesiones/actual`
  * Method: `GET`
  * Parameter: ``
  * Attack: ``
  * Evidence: `no-store`
  * Other Info: ``
* URL: http://localhost:3001/sesiones
  * Node Name: `http://localhost:3001/sesiones ()({correo,contrasena})`
  * Method: `POST`
  * Parameter: ``
  * Attack: ``
  * Evidence: `no-store`
  * Other Info: ``
* URL: http://localhost:3001/sesiones/actual/renovacion
  * Node Name: `http://localhost:3001/sesiones/actual/renovacion`
  * Method: `POST`
  * Parameter: ``
  * Attack: ``
  * Evidence: `no-store`
  * Other Info: ``

Instances: Systemic


### Solution

The content may be marked as storable by ensuring that the following conditions are satisfied:
The request method must be understood by the cache and defined as being cacheable ("GET", "HEAD", and "POST" are currently defined as cacheable)
The response status code must be understood by the cache (one of the 1XX, 2XX, 3XX, 4XX, or 5XX response classes are generally understood)
The "no-store" cache directive must not appear in the request or response header fields
For caching by "shared" caches such as "proxy" caches, the "private" response directive must not appear in the response
For caching by "shared" caches such as "proxy" caches, the "Authorization" header field must not appear in the request, unless the response explicitly allows it (using one of the "must-revalidate", "public", or "s-maxage" Cache-Control response directives)
In addition to the conditions above, at least one of the following conditions must also be satisfied by the response:
It must contain an "Expires" header field
It must contain a "max-age" response directive
For "shared" caches such as "proxy" caches, it must contain a "s-maxage" response directive
It must contain a "Cache Control Extension" that allows it to be cached
It must have a status code that is defined as cacheable by default (200, 203, 204, 206, 300, 301, 404, 405, 410, 414, 501).

### Reference


* [ https://datatracker.ietf.org/doc/html/rfc7234 ](https://datatracker.ietf.org/doc/html/rfc7234)
* [ https://datatracker.ietf.org/doc/html/rfc7231 ](https://datatracker.ietf.org/doc/html/rfc7231)
* [ https://www.w3.org/Protocols/rfc2616/rfc2616-sec13.html ](https://www.w3.org/Protocols/rfc2616/rfc2616-sec13.html)


#### CWE Id: [ 524 ](https://cwe.mitre.org/data/definitions/524.html)


#### WASC Id: 13

#### Source ID: 3

### [ Session Management Response Identified ](https://www.zaproxy.org/docs/alerts/10112/)



##### Informational (Medium)

### Description

The given response has been identified as containing a session management token. The 'Other Info' field contains a set of header tokens that can be used in the Header Based Session Management Method. If the request is in a context which has a Session Management Method set to "Auto-Detect" then this rule will change the session management to use the tokens identified.

* URL: http://localhost:3001/sesiones/actual/renovacion
  * Node Name: `http://localhost:3001/sesiones/actual/renovacion`
  * Method: `POST`
  * Parameter: `token`
  * Attack: ``
  * Evidence: `token`
  * Other Info: `json:token`


Instances: 1

### Solution

This is an informational alert rather than a vulnerability and so there is nothing to fix.

### Reference


* [ https://www.zaproxy.org/docs/desktop/addons/authentication-helper/session-mgmt-id/ ](https://www.zaproxy.org/docs/desktop/addons/authentication-helper/session-mgmt-id/)



#### Source ID: 3


