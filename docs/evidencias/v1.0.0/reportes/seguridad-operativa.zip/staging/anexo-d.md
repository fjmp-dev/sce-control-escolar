### Anexo D, apartado 1: humo en staging (seguridad-2)

| Verificación | Resultado y evidencia |
|---|---|
| Inicio de sesión por cada rol | Cumple: humo.txt (API y portal, 7 roles) |
| Inscripción: una confirmada y un rechazo de cada motivo | Cumple: newman (CI-API-01; CF-INS-01 y 02 por prerrequisito, adeudo, choque y cupo) |
| Consulta de horario y calificaciones | Cumple: newman (Mis inscripciones con su horario; CI-CAL-01 calificaciones) |
| Pago con doble notificación sin duplicar | Cumple: newman (CI-PAG-01 con el aviso repetido de la pasarela simulada, CC-020) |
| `/salud` de API y de web responde | Cumple: humo.txt |
| HTTPS con TLS 1.2 o superior | Cumple: tls/tls.json, HTTP a HTTPS y HSTS |
| Sin matrículas reales (18.2, RK-09) | Cumple: sin-datos-reales.txt |
| Accesos revisados (sección 18) | Cumple: accesos.txt |
